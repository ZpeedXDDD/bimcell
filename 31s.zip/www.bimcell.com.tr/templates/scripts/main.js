﻿$(document).ready(function () {


    $(".content-sidebar li.selected").prev().css("border-bottom","none");


});