$(function(){
	//console.log("ready");

	$(window).on('load', function() {
		$('#oimPopup').modal('show');
		var isActiveMenu=false;
		if(localStorage.getItem('selectedMenu')){
			$('.li_'+localStorage.getItem('selectedMenu')).find("a").each(function() {
				if (this.outerHTML.indexOf(requestedCommand) > 0) {
					$('.li_'+localStorage.getItem('selectedMenu')).addClass('active');
					$('.ul_'+localStorage.getItem('selectedMenu')).show();
					if(this.id.length != 3) {
						localStorage.setItem('selectedMenuItem',this.id);
					}
					isActiveMenu=true;
					return false;
				}

			});
		}
		if(!isActiveMenu){
			findActiveMenu();
			return false;
		}
		if(localStorage.getItem('selectedMenuItem')){
			$('.'+localStorage.getItem('selectedMenuItem')).addClass('activeSubMenu');
		}
	});

	function findActiveMenu() {
		var menuCount = $('.main-menu li').find("a[onclick*='" + requestedCommand + "']").length;
		if (menuCount > 0 && menuCount <= 2) {
			$('.main-menu a').each(function () {
				if (this.outerHTML !== "" && this.outerHTML.indexOf(requestedCommand) > 0) {
					var closestLiElement = $(this).closest("li");
					var ulElement = closestLiElement.parent();
					var liElement = ulElement.parent();
					var liClassName = liElement[0].className;
					if (liClassName !== "" && liClassName.indexOf('main-menu') < 0) {
						liElement.addClass('active');
						ulElement.show();
						$(this).addClass('activeSubMenu');
					} else if (closestLiElement[0].className !== "" && closestLiElement[0].className.indexOf('main-menu') < 0) {
						closestLiElement.addClass('active');
					}
				}
			});
		}
	}

	// $(".main-menu li a").click(function(e){
	// 	//console.log("test");
	// 	e.preventDefault();
	// });

	$('.main-menu li > a').click(function(e) {
		e.preventDefault();

		var $this = $(this);
		$('.main-menu li').removeClass('active');

		if(!$this.next().is(":visible")){
			$this.parents().addClass('active');
		}
		if($this[0].id.length == 3){
			localStorage.setItem('selectedMenu', $this[0].id)
		}else{
			if($this[0].id.length > 4){
				localStorage.setItem('selectedMenu',$this[0].id.substring(0, ($this[0].id.length-2)));
			}
			else{
				localStorage.setItem('selectedMenu',$this[0].id.substring(0, ($this[0].id.length-1)));
			}
			localStorage.setItem('selectedMenuItem',$this[0].id);
		}


		if ($this.next().hasClass('show')) {
			$this.next().removeClass('show');
			$this.next().stop().slideUp(350);
		} else {
			$this.parent().parent().find('li .inner').removeClass('show');
			$this.parent().parent().find('li .inner').stop().slideUp(350);
			// $this.next().toggleClass('show');
			$this.next().stop().slideToggle(350);
		}
	});



	$(".menu-wrapper").click(function(){
		$(".main-menu-mobil").removeClass('show').slideToggle();
		$(".mobileSideBar").removeClass('show').slideToggle();
		$(this).find('i').toggleClass('mobile-menu-down mobile-menu-up');
	});


	$('.svg-convert').svgConvert({
			onComplete: function() {
				console.log("Finished Converting SVG's");
			},
			imgIncludeAttr: true,
			svgCleanupAttr: []
		}
	);

	$(".user-button").click(function(event) {
		/* Act on the event */
		$(".user-button ul").stop().slideToggle("slow");
		$(".user-button a").toggleClass("active");
	});

	$(".user-button ul, .user-button").hover(function(){},function(e){
		e.preventDefault();
		$(".user-button ul").slideUp("slow");
	})

	$(".login-menu .nav li").hover(function(){
		$(this).children('.submenu').show();
	},function(){
		$(this).children('.submenu').hide();
	});

	$("ul.submenu.mobil-submenu li").on("touchstart", function(e) {
		$("ul.submenu.mobil-submenu li").children('img').css({"visibility":"hidden"});
		$(this).children('img').css({"visibility":"visible"});
	});

	$("ul.submenu.tv-submenu li").on("touchstart", function(e) {
		$("ul.submenu.tv-submenu li").children('img').css({"visibility":"hidden"});
		$(this).children('img').css({"visibility":"visible"});
	});

	$("ul.submenu.evtelefonu-submenu li").on("touchstart", function(e) {
		$("ul.submenu.evtelefonu-submenu li").children('img').css({"visibility":"hidden"});
		$(this).children('img').css({"visibility":"visible"});
	});

	toggleButtonClick();

	// Jquery date picker


});


var isAndroid = /android/i.test(navigator.userAgent.toLowerCase());
var isiPhone = /iphone/i.test(navigator.userAgent.toLowerCase());
var is_iPad = navigator.userAgent.match(/iPad/i) != null;



function toggleButtonClick() {


	if (isAndroid) {


		$(".login-menu li").on("touchstart", function(e) {
			e.preventDefault();
			if ($(this).hasClass("click")) {
				//console.log("class var");
				$(this).removeClass("click");
				$(this).children('.submenu').hide();
			} else {
				//console.log("class yok");
				$(".login-menu li").removeClass("click");
				$(this).addClass("click");
				$(".login-menu li").children('.submenu').hide();
				$(this).children('.submenu').show();
			}
		});
		$(document).on("click",":not(.login-menu)", function(e) {
			$(".login-menu li").removeClass("click");
			$(".login-menu li").children('.submenu').hide();
		});
	}

	if (isiPhone || is_iPad) {
		$(".login-menu li").on("touchstart", function(e) {
			e.preventDefault();
			if ($(this).hasClass("click")) {
				//console.log("class var");
				$(this).removeClass("click");
				$(this).children('.submenu').hide();
			} else {
				//console.log("class yok");
				$(".login-menu li").removeClass("click");
				$(this).addClass("click");
				$(".login-menu li").children('.submenu').hide();
				$(this).children('.submenu').show();
			}
		});
		console.log("ios");

		$(document).on("click",":not(.login-menu)", function(e) {
			$(".login-menu li").removeClass("click");
			$(".login-menu li").children('.submenu').hide();
		});
	}
}
