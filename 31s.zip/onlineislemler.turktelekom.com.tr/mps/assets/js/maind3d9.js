$(document).ready(function () {


	/* Pia Changes */

	// Safari Fix (For Table Resize Problem On Desktop Safari Browsers)
	var mode = "";

	var setupSafariDesktopResponsiveTablesFix = function(){
		Response.resize(_.debounce(function(){
			// Mobile
			if(Response.viewportW() < 768 && mode == "not_mobile"){
				jQuery(".res-table").hide();
			}
			// Not Mobile
			else if(Response.viewportW() > 767 && mode == "mobile"){
				jQuery(".res-table").hide();
			}
		}, 100));

		Response.resize(_.debounce(function(){
			// Mobile
			if(Response.viewportW() < 768){
				jQuery(".res-table").removeAttr("style");
				mode = "mobile";
			}
			// Not Mobile
			else if(Response.viewportW() > 767){
				jQuery(".res-table").removeAttr("style");
				mode = "not_mobile";
			}
		}, 150));
	};

	// Browser Detection
	var browser = window.navigator.userAgent;

	// Desktop Safari
	if(browser.toString().toLowerCase().indexOf("safari") != -1 &&
		browser.toString().toLowerCase().indexOf("chrome") == -1 &&
		browser.toString().toLowerCase().indexOf("mobile") == -1){
		setupSafariDesktopResponsiveTablesFix();
	}
	/* Pia Changes End */

	//	FastClick.attach(document.body);
	$("form").attr("autocomplete", "off");
	//  document.getElementById("table-responsive").addEventListener('touchstart', function (event) { });
	//  $(".bfh-datepicker").bfhdatepicker()
	//$('h1').addClass('animated bounceIn');
	//$('.frame').addClass('animated bounceInLeft');
	//$('.breadcrumb').addClass('animated bounceInLeft');
	//$('.mobile-btn-group').addClass('animated bounceInRight');
	$('.login-hint').hover(function () {
			$('.login-hint-content').show();
		},
		function () {
			$('.login-hint-content').hide();
		});
	$(window).load(function () {
		$(".start-overlay").stop(true).show();
		$(".loader-1, .loader-2").stop(true).delay(400).fadeOut(300);
		$(".start-overlay").stop(true).delay(500).fadeOut(500);
	});
	function toggleChevron(e) {
		$(e.target).prev('.panel-heading').find("i.indicator").toggleClass('i-angle-down-two  icon-angle-up  i-angle-up');
	}
	// $('#accordion').on('hidden.bs.collapse', toggleChevron);
	// $('#accordion').on('shown.bs.collapse', toggleChevron);

	$(".demand-nav a").hover(
		function () {
			$(this).find("img").css("display", "inline-block");
		},
		function () {
			$(this).find("img").css("display", "none");
		});

	if ($.fn.collapse) $('.collapse').collapse();

	// For Popover
	;(function(){

		$(document).on('click touchstart', function(){
			$('[data-toggle="popover"]').popover('yally');
		});

		$(document).on('click touchstart', '.popover', function(e){
			e.stopPropagation();
		});

		$(document).on('click touchstart', '[data-toggle="popover"]', function(e){
			$('[data-toggle="popover"]').not(this).popover('yally');
			e.stopPropagation();
		});

	})();

	// For Mobile Menu
	;(function(){

		if ( !$.fn.mmenu ) return;

		var navigation = $(document.getElementById('menu'));

		var navigationController = navigation.mmenu({
			classes: "mm-light",
			position: "bottom",
			zposition: "front",
			slidingSubmenus: false
		});

		/* Pia Changes */
		if(browser.toString().indexOf("MSIE 8.0") == -1){
			navigation.on("click", "a", function(){
				var __self = $(this);
				if ( __self.hasClass("mm-subopen") )
					navigation.find("li.mm-opened").not(__self.parent()).removeClass("mm-opened");
				else
					navigationController.trigger('close');
			});

			$(window).resize(function(){
				navigationController.trigger('close');
			});
		}
		$.support.placeholder = true;
		if(navigator.userAgent.toString().indexOf("MSIE") > -1)
			$.support.placeholder = false;
		if (!$.support.placeholder) {
			var active = document.activeElement;

			$(':text').focus(function() {
				if ($(this).attr('placeholder') != '' && $(this).val() == $(this).attr('placeholder')) {
					$(this).val('').removeClass('hasPlaceholder');
				}
			}).blur(function() {
				if ($(this).attr('placeholder') != '' && ($(this).val() == '' || $(this).val() == $(this).attr('placeholder'))) {
					$(this).val($(this).attr('placeholder')).addClass('hasPlaceholder');
				}
			});
			$(':text').blur();

			$(active).focus();
		}
		/* Pia Changes End */

	})();

	// Tab Content
	$(".tab_content").hide();
	$(".tab_content:first").show();
	$(".showDiv").click(function () {
		$(".tab_content").hide();
		var activeTab = $(this).attr("formaction");
		$("#" + activeTab).fadeIn();
		$(".showDiv").removeClass("active");
		$(this).addClass("active");
	});
	$('.showDiv').last().addClass("tab_last");
	// For First Ready
	triggerDocument();

	if($('#showVideoLightBox video').length>0) {
		var videoPath = 'assets/videos/';
		$('.45GX2, .45GWorld, .efaturayatayv2').on('click', '.videoLink', function(){
			var parent = $(this).parent();
			var videoSrc = parent.data('videosrc');

			$('#showVideoLightBox').fadeIn('slow');
			var videoElem = $('#showVideoLightBox video').get(0);
			videoElem.src = videoPath+videoSrc;
			videoElem.currentTime = 0;
			videoElem.play();
			sendVideoLogRequest(videoSrc);
		});


		$('.imageLink').on('click', function(){
			var imageSrc = $(this).data('imagesrc');
			sendImageLogRequest(imageSrc);
		});

		$('.imageLink2').on('click', function(){
			var imageSrc = "8MartDunyaKadinlarGunuKampanyasi.jpg";
			sendImageLogRequest(imageSrc);
		});





		$('#showVideoLightBox .closeVideo').on('click',function(){
			$('#showVideoLightBox video').get(0).pause();
			$('#showVideoLightBox').hide();
		});

		$('#showVideoLightBox video').get(0).onended = function(e) {
			$('#showVideoLightBox').hide();
		};
		$('#showVideoLightBox video').on('click',function(){
			var videoElem = $(this).get(0);
			if(videoElem.paused)
				videoElem.play();
			else
				videoElem.pause();
		});
	}

	const target = document.documentElement;
	const config = {
		attributes: true,
		childList: true,
		subtree: true,
		characterData: true,
		attributeOldValue: true,
		characterDataOldValue: true
	};
	const callback = function(mutationsList, observer) {
		requestResize();
	};

	const observer = new MutationObserver(callback);
	observer.observe(target, config)
	
	if(typeof msisdn !== "undefined" && !localStorage.getItem('cookiePolicyWarning'+msisdn)) {
        $('#cookie-policy-warning').slideDown('fast');
        
        $('#cookie-policy-warning').on('click', 'span.close', function(){
            $('#cookie-policy-warning').slideUp('fast');
            localStorage.setItem('cookiePolicyWarning'+msisdn, 'ok');
        });
        
        $('#cookie-policy-warning').on('click', '.cookie-policy-link', function(){
            localStorage.setItem('cookiePolicyWarning'+msisdn, 'ok');
            sendhref('cookiePolicy');
        });
    }
});
// PushState and PopState Controller
(function(){
	// PopState Event
	$(window).bind('popstate', function (e) {
		var state = e.originalEvent.state;
		if (state) sendhref(state.requestedCommand, 'popstate');
	});
	// Replace State
	if (typeof history.replaceState === 'function' && typeof requestedCommand !== 'undefined')
	{
		var queryString = getQueryString({ cmd : requestedCommand });
		history.replaceState({requestedCommand: requestedCommand}, null, "/mps/portal?" + buildQueryString(queryString));
	}
})();

// Flags
window.ajaxScrollToTop = true;
window.sendHrefXHR = null;

// Functions
function queryString()
{
	return location.href.split('?')[1];
}
function getQueryString(params)
{
	var result = {},
		parameters = queryString().split('&');

	for ( var i in parameters )
	{
		var param = parameters[i].split('=');
		result[decodeURIComponent(param[0])] = decodeURIComponent(param[1]);
	}

	if ( typeof params !== 'undefined' )
	{
		for ( var k in params ) result[k] = params[k];
	}

	return result;
}
function buildQueryString(params)
{
	var result = [];

	for ( var i in params )
		result.push(i + "=" + encodeURIComponent(params[i]));

	return result.join('&');
}
function countChar(val) {
	var len = val.value.length;
	if (len >= 500) {
		val.value = val.value.substring(0, 500);
	} else {
		$('#charNum').text(500 - len);
	}
};
function countChar2(val) {
	var len = val.value.length;
	if (len >= 250) {
		val.value = val.value.substring(0, 250);
	} else {
		$('#charNum2').text(250 - len);
	}
};
function countChar3(val) {
	var len = val.value.length;
	if (len >= 1000) {
		val.value = val.value.substring(0, 1000);
	} else {
		$('#charNum3').text(1000 - len);
	}
};
function showLoading() {
	$(".start-overlay").stop(true).show();
	$(".loader-1, .loader-2").stop(true).show();
}
function CloseLoading() {
	$(document).trigger('ready');
}
/*
function BorderRadiusWithoutPrefix()
{
    var result = false,
        element = document.createElement('div');
    element.style.borderRadius = '1px';
    document.body.appendChild(element);
    var computed = getComputedStyle(element);
    if ( computed.borderRadius == '1px' ) result = true;
    element.parentNode.removeChild(element);
    return result;
}
function FixAllTabs()
{
 	if ( BorderRadiusWithoutPrefix() !== true )
	{
       	$('ul.nav.nav-tabs.nav-justified').each(function(){
       	   var children = $(this).children(),
       	       width = 100 / children.length;
       	   children.width(width + '%');
       	});
	}
}
*/
function popoverSetup()
{
	if ($.fn.popover) $('[data-toggle="popover"]').popover({trigger: "click"});
}
function triggerDocument()
{
	//$(document).trigger('ready');
	popoverSetup();
	setResponsiveTables();
	customInputController();
	setAdvancedDatepickers();
	setTableControls();
	//FixAllTabs();
	if(window.ajaxScrollToTop != null && window.ajaxScrollToTop == true)
		$('html, body').animate({ scrollTop : 0 });
	if ( typeof current === 'undefined' )
		current = 540;
}
function setStep(m_step) {
	//alert('Hello');
	document.referenceSystemForm.step.value = m_step;
}
function sendhref(command, type) {
	blockUILoadingDefault();
	var targetURL = '/mps/portal?cmd=' + command;
	window.location.href = targetURL;
	/*
	var isIE8 = (navigator.userAgent.toString().indexOf("MSIE 8.0") != -1 ? true : false);
	if (typeof history.pushState === 'function' || isIE8 ) {

 		if(window.sendHrefXHR != null){
 			window.sendHrefXHR.abort();
 		}
		// Set Command Link
		$(document.getElementById('hiddeninputid')).val(targetURL);
		// Progress Bar
		NProgress.start();
		// PushState Event

        // XMLHttpRequest
		window.sendHrefXHR = $.ajax(targetURL, {
			cache: false,
			data: { link: targetURL },
			success: function (response) {
				if(response.indexOf("</html>") > 0) {
					var newDoc = document.open("text/html", "replace");
					newDoc.write(response);
					newDoc.close();
				}
				else{
					$('#actionsContentArea').html(response);
				}
    			NProgress.done();
    			CloseLoading();
    			triggerDocument();
			
				if ( type !== 'popstate' && !isIE8 )
					history.pushState({ requestedCommand: command }, null, targetURL);
				
			},
			error: function(xhr){
				if(xhr.status == 302 || xhr.status == 404){
					var newDoc = document.open("text/html", "replace");
					newDoc.write(xhr.responseText);
					newDoc.close();
					
					if ( type !== 'popstate' && !isIE8 )
						history.pushState({ requestedCommand: command }, null, targetURL);
				}
			}
		});
	}
	else location.href = targetURL;
	return false;
	*/
}
function sendhrefpost(cmd) {
	var aveaurl = '/mps/portal?cmd=' + cmd;
	$('input[id=hiddeninputid]').val(aveaurl);
	//$.post(aveaurl, { link: aveaurl }, function (data) {   alert(data);   $('#actionsContentArea').html(data);    });
	//return false;
	$.ajaxSetup({
		'cache': false
	})
	$.ajax({
		type: 'POST',
		url: aveaurl,
		data: aveaurl,
		success: function (response) {
			alert(response);
			$('#actionsContentArea').html(response);
		}
	});
	return false;
}
function sendajax(formn) {
	// showLoading();
	var url = $('#hiddeninputid').val();
	var querystring = $('#' + formn).serialize();
	$.ajaxSetup({
		'cache': false
	})
	$.get(url, {
			datasubmited: querystring
		},
		function (data) {
			$('#actionsContentArea').html(data);
			//  CloseLoading();
			triggerDocument();
		});
	return false;
}
function sendajaxp(formn) {
	var url = $('#hiddeninputid').val();
	var querystring = $('#' + formn).serialize();
	$.ajaxSetup({
		'cache': false
	})
	$.post(url, {
			datasubmited: querystring
		},
		function (data) {
			$('#actionsContentArea').html(data);
			triggerDocument();
		});
	return false;
}
function sendajaxgetf(formn, callback) {
	var $form = $("#" + formn).serialize();
	$.ajaxSetup({
		'cache': false
	})
	NProgress.start();
	$.ajax({
		type: 'get',
		url: $('#hiddeninputid').val(),
		data: $form,
		success: function (response) {
			$('#actionsContentArea').html(response);
			NProgress.done();
			$('.fade').removeClass('out');
			$.unblockUI();
			CloseLoading();
			triggerDocument();
			if ( typeof callback === "function" ) callback();
			if ( typeof resetPrimeSelect === "function" ) resetPrimeSelect();
		}
	});
	return false;
}
function sendajaxpost(formn) {
	var $form = $("#" + formn);
	$form.submit(function () {
		$.ajaxSetup({
			'cache': false
		})
		$.ajax({
			type: 'POST',
			url: $('#hiddeninputid').val(),
			data: $(formn).serialize(),
			success: function (response) {
				$('#actionsContentArea').html(response);
				triggerDocument();
			}
		});
		return false;
	});
}
function sendajaxpostf(formn, callback, errorCallback) {
	var $form = $("#" + formn).serialize();
	$.ajaxSetup({
		'cache': false
	})
	NProgress.configure({ showSpinner: false });
	NProgress.start();
	newblockUILoading('İşleminiz gerçekleştiriliyor!');
	$.ajax({
		type: 'POST',
		url: $('#hiddeninputid').val(),
		data: $form,
		success: function (response) {
			unblockUI();
			$('#actionsContentArea').html(response);
			NProgress.done();
			$('.fade').removeClass('out');
			CloseLoading();
			triggerDocument();
			if ( typeof callback === "function" ) callback(response);
			if ( typeof resetPrimeSelect === "function" ) resetPrimeSelect();
			return false;
		},
		error: function(xhr){
			unblockUI();
			if ( typeof errorCallback === "function" ) errorCallback(xhr);
		}
	});
	return false;
}
/* For birthday message */
function GetModalImage(image){

	var html = [];

	html.push('<table class="mt10 mb10">');
	html.push('<tr>');
	html.push('<td class="pl10"><img class="birthdaymessage" src="'+ image +'" alt="..." /></td>');
	html.push('<td class="pl10 pr10"></td>');
	html.push('</tr>');

	html.push('</table>');

	return html.join('');
}


function ShowBirthdayModal(image){
	var box =  $('#modal-general-alert').clone();
	var $content = box.find('#modal-body-content');
	$content.html(GetModalImage(image));

	box.find('.btn-seven').click(function(){
		returnStatus = true;
		ifOkeyFuction(box);
	});

	box.modal("show");

	return box;
}
/* end birthday message */

function GetModalMessage(message, status)
{
	status = status || "warning";
	message = message || "İşleminiz gerçekleştirilemiyor. Lütfen daha sonra tekrar deneyiniz."

	var icons = {
		"warning" : "icon-attention-circled i-exclamation"
		/* "success" : "icon-ok-circled i-ok-circle" */
	}

	var html = [];

	html.push('<div class="row">');
	html.push('<div class="col-md-12">');
	html.push('<p>' +message+ '</p>');
	html.push('</div>');
	html.push('</div>');

	return html.join('');
}
function GetModalMessageWithImage(message, image)
{

	message = message || "İşleminiz gerçekleştirilemiyor. Lütfen daha sonra tekrar deneyiniz."
	var html = [];

	html.push('<table class="mt10 mb10">');
	html.push('<tr>');
	html.push('<td class="pl10"><img height="130px" src="'+ image +'" alt="..." /></td>');
	html.push('<td class="pl10 pr10">' +message+ '</td>');
	html.push('</tr>');
	html.push('<tr id="rejectTR">');
	html.push('<td class="pl10" style = "top-padding:20px"colspan="2">');
	html.push('<label><input type="checkbox" id="reject" name="reject"/><span class="dib pt2">Bir daha gösterme</span></label>');
	html.push('</td>');
	html.push('</tr>');
	html.push('</table>');

	return html.join('');
}
/* For Confirmation With Okey and Cancel */
function ShowModal(showedText, ifOkeyFuction, ifNoFuction)
{
	var returnStatus = false,
		CustomModal = $(document.getElementById('modal-general'));

	$(document.getElementById('modal-confirm-body-content')).html(GetModalMessage(showedText));

	CustomModal.modal('show');

	CustomModal.on('click', '.okBtn', function(){
		returnStatus = true;
		CustomModal.modal('hide');
	});

	CustomModal.on('click', '.cancelBtn', function(){
		returnStatus = false;
		CustomModal.modal('hide');
	});

	CustomModal.on('hidden.bs.modal', function(){
		CustomModal.off('click');
		CustomModal.off('hidden.bs.modal');
		if ( returnStatus === true && typeof ifOkeyFuction === 'function' ) ifOkeyFuction();
		if ( returnStatus === false && typeof ifNoFuction === 'function' ) ifNoFuction();
	});

	var clientRec = document.body.getBoundingClientRect();

}
function ShowAcmeModal(showedText, ifOkeyFuction, ifNoFuction)
{
	var returnStatus = false,
		CustomModal = $(document.getElementById('acme-modal-general'));

	$(document.getElementById('acme-modal-confirm-body-content')).html(GetModalMessage(showedText));

	CustomModal.modal('show');

	CustomModal.on('click', '.okBtn', function(){
		returnStatus = true;
		CustomModal.modal('hide');
	});

	CustomModal.on('click', '.cancelBtn', function(){
		returnStatus = false;
		CustomModal.modal('hide');
	});

	CustomModal.on('hidden.bs.modal', function(){
		CustomModal.off('click');
		CustomModal.off('hidden.bs.modal');
		if ( returnStatus === true && typeof ifOkeyFuction === 'function' ) ifOkeyFuction();
		if ( returnStatus === false && typeof ifNoFuction === 'function' ) ifNoFuction();
	});

	var clientRec = document.body.getBoundingClientRect();

}

/* For Confirmation With Okey and Cancel */
function ShowBenefitModal(showedText,image, ifOkeyFuction, ifNoFuction)
{
	var returnStatus = false,
		CustomModal = $(document.getElementById('modal-benefit-alert'));

	$(document.getElementById('modal-benefit-body-content')).html(GetModalMessageWithImage(showedText, image));

	CustomModal.modal('show');

	CustomModal.on('click', '.okBtn', function(){
		returnStatus = true;
		CustomModal.modal('hide');
	});

	CustomModal.on('click', '.cancelBtn', function(){
		returnStatus = false;
		CustomModal.modal('hide');
	});

	CustomModal.on('hidden.bs.modal', function(){
		CustomModal.off('click');
		CustomModal.off('hidden.bs.modal');
		if ( returnStatus === true && typeof ifOkeyFuction === 'function' ) ifOkeyFuction();
		if ( returnStatus === false && typeof ifNoFuction === 'function' ) ifNoFuction();
	});
}




/* For Confirmation With Okey and Cancel */
function ShowCloneBenefitModal(showedText,image, ifOkeyFuction, ifNoFuction,benefit)
{
	var returnStatus = false;
	var box =  $('#ove-modal-benefit-alert').clone();
	var $content = box.find('#ove-modal-benefit-body-content');
	$content.html(GetModalMessageWithImage(benefit.text, benefit.image));

	if ( benefit.showOk != 'Y'){
		box.find("#ove-modal-benefit-ok").hide();
	}
	else{
		box.find("#ove-modal-benefit-ok").show();
	}

	if ( benefit.showCancel != 'Y'){
		box.find("#ove-modal-benefit-cancel").hide();
	}
	else{
		box.find("#ove-modal-benefit-cancel").show();
	}
	if ( (jQuery.isEmptyObject(benefit.params)|| benefit.params.length == 0 )){
		box.find("#ove-modal-benefit-ok").html("Tamam");
	}
	else{
		box.find("#ove-modal-benefit-ok").html("Onayla");
	}


	box.find('.ove-okBtn').click(function(){
		returnStatus = true;

		ifOkeyFuction(box);
	});

	box.find('.ove-cancelBtn').click(function(){
		returnStatus = false;
		ifNoFuction(box);
	});

	benefit.box.modal("hide");
	benefit.box = box;



	return box;
}


function ShowModalCloneBenefit(message,type,preBenefit,ifOkeyFuction)
{
	var box =  $('#modal-general-alert').clone();
	var $content = box.find('#modal-body-content');
	$content.html(GetModalMessage(message, type));

	box.find('.btn-seven').click(function(){
		returnStatus = true;
		ifOkeyFuction(box);
	});

	if(preBenefit)
		preBenefit.modal("hide");


	console.log(box.html()+"  message  "+message+"  type  "+type+"  preBenefit  "+preBenefit+"  ifOkeyFuction  "+ifOkeyFuction);

	box.modal("show");

	return box;
}





function ShowBenefitInputModal(html,ifOkeyFuction, ifNoFuction)
{
	var returnStatus = false,
		CustomModal = $(document.getElementById('modal-benefit-alert'));

	$(document.getElementById('modal-benefit-body-content')).html(html);

	CustomModal.modal('show');

	myEmailFlag =1;
	$( "#ruleemail" ).keydown(function() {
		myEmailFlag = 0 ;
	});


	CustomModal.on('click', '.okBtn', function(){
		if(typeof $('#ruleemail').val() === "undefined" ){
			returnStatus = true;
			CustomModal.modal('hide');

		}
		else {

			if ($('#ruleemail').val().match(/.+@.+\..+/g)  == null || $('#ruleemail').val() == "")  {
				$('#ruleemail').addClass('error');

				$('#ruleemail-error').css('display','block');
				$('#ruleemail-error').html('!Lütfen geçerli bir e-mail bilgisi giriniz.');

				if ( myEmailFlag ) {

					var $label = $("<label id='ruleemail-error' class='error' for='ruleemail' style='display: block;'>").text('!Lütfen geçerli bir e-mail bilgisi giriniz.');

					$label.insertAfter( "#ruleemail" );
					myEmailFlag =0;
				}

			}else {
				console.log("test");
				returnStatus = true;
				CustomModal.modal('hide');
			}
		}


	});

	/*
	$(function(){
	    $('.okBtn').click(function(){
	    i = 0;
	       $('input').each(function(){
	          var val = $.trim($(this).val());
	          if( !val ){ i += 1; }
	       });
	       if( i > 0 ){
				$('#ruleemail').addClass('error');
		   }
	    });
	});
	
	*/



	CustomModal.on('click', '.cancelBtn', function(){
		returnStatus = false;
		CustomModal.modal('hide');
	});

	CustomModal.on('hidden.bs.modal', function(){
		CustomModal.off('click');
		CustomModal.off('hidden.bs.modal');
		if ( returnStatus === true && typeof ifOkeyFuction === 'function' ) ifOkeyFuction();
		if ( returnStatus === false && typeof ifNoFuction === 'function' ) ifNoFuction();
	});
}
/* Redirecting ShowModal Function For Cancelable */
function ShowModalWithFalse(showedText, ifOkeyFuction, ifNoFuction)
{
	ShowModal(showedText, ifOkeyFuction, ifNoFuction);
}

function ShowModalWithType(message, type)
{
	$(document.getElementById('modal-body-content')).html(GetModalMessage(message, type));
	$(document.getElementById('modal-general-alert-top')).html(getTopSideSvgForSuccessOrWarning(type));
	$(document.getElementById('modal-general-alert-right')).html(getRightSideSvgForSuccessOrWarning(type));
	$(document.getElementById('modal-general-alert')).modal('show');

	var clientRec = document.body.getBoundingClientRect();


}
function ShowModalText(message, type)
{
	$(document.getElementById('sozlesme-modal-body-content')).html(GetModalMessage(message, type));
	$(document.getElementById('modal-general-sozlesme')).modal('show');

	var clientRec = document.body.getBoundingClientRect();
	if(clientRec.y === 0) {
		$('#modal-general-sozlesme').css('top', window.top.scrollY-150);
	}

}


function ShowModalAcmeType(message, ifOkeyFuction, ifNoFuction)
{
	CustomModal = $(document.getElementById('acme-modal-general'));

	$(document.getElementById('acme-modal-confirm-body-content')).html(GetModalMessage(message, ifOkeyFuction));
	$(document.getElementById('acme-modal-general-alert-top')).html(getTopSideSvgForSuccessOrWarning(ifOkeyFuction));
	$(document.getElementById('acme-modal-general-alert-right')).html(getRightSideSvgForSuccessOrWarning(ifOkeyFuction));
	$(document.getElementById('acme-modal-general')).modal('show');

	CustomModal.on('click', '.okBtn', function(){
		returnStatus = true;
		CustomModal.modal('hide');
	});

	CustomModal.on('click', '.cancelBtn', function(){
		returnStatus = false;
		CustomModal.modal('hide');
	});

	CustomModal.on('hidden.bs.modal', function(){
		CustomModal.off('click');
		CustomModal.off('hidden.bs.modal');
		if ( returnStatus === true && typeof ifOkeyFuction === 'function' ) ifOkeyFuction();
		if ( returnStatus === false && typeof ifNoFuction === 'function' ) ifNoFuction();
	});

	var clientRec = document.body.getBoundingClientRect();
	if(clientRec.y === 0) {
		$('#acme-modal-general').css('top', window.top.scrollY-150);
	}

}

function ShowModalWithTypeGuest(message, type)
{
	$("#modal-general-alert-guest").find("#modal-body-content").html(GetModalMessage(message, type));
	$("#modal-general-alert-guest").find("#modal-general-alert-top").html('<img src="assets/images/guestwarning.svg" />');
	$("#modal-general-alert-guest").find("#modal-general-alert-right").html('<img src="assets/images/guestwarning.svg" />');
	$(document.getElementById('modal-general-alert-guest')).modal('show');




}

function ShowModalAlertWithCheckbox(message,image,ifOkeyFuction)
{
	$(document.getElementById('modal-campaign-body-content')).html(GetModalMessageWithImage(message, image));
	$(document.getElementById('modal-campaign-alert')).modal('show');
	CustomModal = $(document.getElementById('modal-campaign-alert'));
	CustomModal.modal('show');
	CustomModal.on('click', '.okBtn', function(){
		CustomModal.modal('hide');
	});
	CustomModal.on('hidden.bs.modal', function(){
		CustomModal.off('click');
		CustomModal.off('hidden.bs.modal');
		if ( typeof ifOkeyFuction === 'function' ) ifOkeyFuction($("#reject").is(':checked') ? 'Y' : 'N');
	});
}
function ShowModalAlert(message)
{
	ShowModalWithType(message, "warning");
}

function ShowModalContract(message)
{
	ShowModalText(message, "warning");
}

function ShowModalSuccess(message)
{
	ShowModalWithType(message, "success");
}

function ShowModalAlertGuest(message)
{
	ShowModalWithTypeGuest(message, "warning");
}



function sendGetRequestNew(myUrl, myData, useBlockUI) {
	if (useBlockUI) {
		blockUILoadingDefault();
	}
	try {
		$.ajaxSetup({
			headers: {
				'ajax': 'true'
			}
		});
		$.ajax({
			type: 'GET',
			url: $('#hiddeninputid').val(),
			data: myData,
			success: function (response) {
				handleSessionTimeout(response);
				successgetcallback(response);
			},
			error: function () {
				$.unblockUI();
				ShowModalAlert();
			}
		});
		var current_config = $.ajaxSetup();
		//console.log("after",current_config);
		delete current_config.headers;
		//console.log("after2",current_config);
	}
	catch (err) {
		ShowModalAlert();
	}
}
function sendVideoLogRequest(videoSrc) {
	$.ajaxSetup({
		headers: {
			'ajax': 'true'
		}
	});
	$.ajax({
		type: 'GET',
		url: '/mps/portal?cmd=logging&videoSrc='+videoSrc,
		success: function (response) { console.log(videoSrc + ' logged')},
		error: function () {console.log(videoSrc + ' log error') }
	});
	var current_config = $.ajaxSetup();
	//console.log("after",current_config);
	delete current_config.headers;
}

function sendImageLogRequest(imageSrc) {
	$.ajaxSetup({
		headers: {
			'ajax': 'true'
		}
	});
	$.ajax({
		type: 'GET',
		url: '/mps/portal?cmd=logging&imageSrc='+imageSrc,
		success: function (response) { console.log(imageSrc + ' logged')},
		error: function () {console.log(imageSrc + ' log error') }
	});
	var current_config = $.ajaxSetup();
	//console.log("after",current_config);
	delete current_config.headers;
}





function sendFormRequestNew(myform, myUrl, useBlockUI) {
	if (useBlockUI) {
		blockUILoadingDefault();
	}
	try {
		var form = document.getElementById(myform);
		$.ajaxSetup({
			headers: {
				'ajax': 'true'
			}
		});
		$.ajax({
			type: 'POST',
			url: $('#hiddeninputid').val(),
			data: $(form).serialize(),
			success: function (response) {
				handleSessionTimeout(response);
				successformcallback(response, myform);
			},
			error: function () {
				ShowModalAlert();
			}
		});
		var current_config = $.ajaxSetup();
		//console.log("after",current_config);
		delete current_config.headers;
		//console.log("after2",current_config);
	}
	catch (err) {
		ShowModalAlert();
	}
}
function successgetcallbackdefault(response) {
	var stateResponse = "";
	unblockUI();
	var errorResponse = parseXml(response, "error");
	if (errorResponse != null && errorResponse != "") {
		blockUIFail(errorResponse);
	} else {
		var messageResponse = parseXml(response, "message");
		if (messageResponse != null && messageResponse != "") {
			blockUISuccess(messageResponse);
		}
	}
}
function validateFormA(form) {
	var d1 = $("input[name$='inputStartDate']").val();
	var d2 = $("input[name$='inputEndDate']").val();
	var begDate = d1.split("/");
	var endDate = d2.split("/");
	var newBegDate = begDate[1] + "/" + begDate[0] + "/" + begDate[2];
	var newEndDate = endDate[1] + "/" + endDate[0] + "/" + endDate[2];
	var date1 = new Date(newBegDate);
	var date2 = new Date(newEndDate);
	var timeDiff = date2.getTime() - date1.getTime();
	//alert(timeDiff);
	if (date1.getTime() > date2.getTime()) {
	}
	if (timeDiff < 0) {
		//alert('nooo m');
		ShowModalAlert(tmessage1);
		return false;
	} else {
		var result =(Math.ceil(timeDiff / (1000 * 3600 * 24)) < 31);
		//alert("result=: "+result);
		if (result == false) {
			ShowModalAlert(temessage2);
			return false;
		}
		// generateCallTypeList();
		/* if(document.viewTraffic.callTypeList.value == ';'){
		ShowModalAlert(temessage3);
		return false;
		}
		 */
		sendajaxpostf('viewTraffic');
		//document.body.style.cursor= 'wait';
		//lockScreen();
	}
}
function getCookie(cname) {
	var name = cname + "=";
	var ca = document.cookie.split(';');
	for (var i = 0; i < ca.length; i++) {
		//var c = ca[i].trim();
		var c = ca[i];
		while (c.charAt(0) == ' ') c = c.substring(1, c.length);
		if (c.indexOf(name) == 0) return c.substring(name.length, c.length);
	}
	return "";
}
function setCustomSelectboxes() {
	/*
	jQuery('select.custom-select-box').each(function(){
	var self = $(this);
	if ( self.attr('data-rendered') !== 'true' )
	{
	self.customSelect();
	self.attr('data-rendered', 'true');
	}
	});
	 */
}
/* Pia Changes */
function setTableControls(){
	// Radio Buttons
	$('.radio-row .radio-column').on('click', function(e){
		// Select Elements We Need
		var tr = $(this);
		var radio = tr.find('.radio-container').children('input[type="radio"]');
		var name = radio.attr('name');
		var icon = radio.parent().children('.radio-fake-icon');

		/*
		if(radio.attr("checked") == "checked"){
			radio.prop('checked', false).removeAttr("checked");
			tr.removeClass('alert-success');
			icon.removeClass('glyphicon-checked').addClass('glyphicon-unchecked');
		}
		else {
			// Change Background Of The Row And Make A Pseudo Click On Radio
			tr.siblings().removeClass('alert-success');
			tr.addClass('alert-success');

			// Set Unchecked All Other Radio Button Icons With This Name
			$('input[name="' + name + '"]').each(function(index){
				var uncheck_icon = $(this).parent().children('.radio-fake-icon');
				uncheck_icon.removeClass('glyphicon-check').addClass('glyphicon-unchecked');
				$(this).prop('checked', false).removeAttr("checked");
			});

			// Set Checked This Radio Button Icon
			icon.removeClass('glyphicon-unchecked').addClass('glyphicon-check');

			// Set The Radio Checked In This Row
			radio.prop('checked', true).attr("checked", "checked");
		}
		*/

		// Change Background Of The Row And Make A Pseudo Click On Radio


		// Set Unchecked All Other Radio Button Icons With This Name
		$('input[name="' + name + '"]').each(function(index){
			var uncheck_icon = $(this).parent().children('.radio-fake-icon');
			uncheck_icon.removeClass('glyphicon-check').addClass('glyphicon-unchecked');
			$(this).prop('checked', false).removeAttr("checked");
		});

		// Set Checked This Radio Button Icon
		icon.removeClass('glyphicon-unchecked').addClass('glyphicon-check');

		// Set The Radio Checked In This Row
		radio.prop('checked', true).attr("checked", "checked");
	});


	// Checkboxes
	$('.table-with-checkbox tbody tr').on('change', 'input[type="checkbox"]', function(e){
		// Select Elements We Need
		var row = jQuery(e.delegateTarget);
		var checkbox = jQuery(this);
		var icon = checkbox.parent().children('.glyphicon');
		var checked = checkbox.is(":checked");

		// Set Checked This Checkbox
		if(checked){
			icon.removeClass("glyphicon-unchecked").addClass("glyphicon-check");
			row.addClass('alert-success');
		}
		else {
			icon.removeClass("glyphicon-check").addClass("glyphicon-unchecked");
			row.removeClass('alert-success');
		}
	});

	$('.table-with-checkbox tbody tr td:nth-child(1)').on('click', function(e){
		if(e.target.tagName.toString().toLowerCase() == 'td')
			$(this).find('input[type="checkbox"]').trigger('click');
	});
}
/* Pia Changes End */
function setAdvancedDatepickers(){

	$('.advanced-datepicker').each(function(){

		var __self = $(this),
			__child = __self.children('input[type="text"]');

		if ( __self.attr('data-date-rendered') !== 'true' )
		{
			__self.datetimepicker({
				pickTime : false,
				defaultDate : __child.attr('data-default-date'),
				minDate : __child.attr('data-min-date'),
				maxDate : __child.attr('data-max-date'),
				language : 'tr'
			});
			__self.attr('data-date-rendered', 'true');

			// Pia Changes
			var date = new Date();
			date.setMonth( date.getMonth() - 3);
			if(__child.attr("name") == "startDate"
				|| __child.attr("name") == "inputStartDate"
				|| __child.attr("name") == "endDate"
				|| __child.attr("name") == "inputEndDate"){
				if(__child.attr("month") == "6")
					date.setMonth( date.getMonth() - 3);
				__self.data("DateTimePicker").setMinDate(date);
			}
			// Pia Changes End
		}

	});

}
function setResponsiveTables() {
	$('.responsive-table').each(function () {

		var self = $(this),
			parent = self.parent(),
			head = self.children('thead').length ? self.children('thead').children('tr').first().children('th') : self.children('tbody').children('tr').first().children('th');

		self.children('tbody').children('tr').each(function (row_index, child) {

			if ( child.tagName.toLowerCase() !== 'th' )
			{
				var ignore = 0;

				$(child).children().each(function(index, node){
					var $node = $(node), $colspan = $node.attr('colspan');
					$colspan = $colspan ? parseInt($colspan) : 0;
					if ( $colspan > 1 ) return ignore += $colspan-1;
					var $attribute = head.eq( index + ignore );
					if ( $attribute ) $node.attr('data-th', $attribute.text());
				});
			}

		});

		self.removeClass('responsive-table');
		self.addClass('res-table');

		if (parent.hasClass('table-responsive')) parent.removeClass('table-responsive');

		if(isArm){
			self.hide();
			setTimeout(function(){
				self.show();
			}, 500);
		}
	});
}

function lpad(string, padString, length){
	for(var i = 0; i < length - string.length; i++){
		string = padString + string;
	}
	return string;
}

function OpenBrWindow(theURL,winName,features, myWidth, myHeight, isCenter) {
	var strwinName;
	if(window.screen){
		if(isCenter){
			if(isCenter=="true"){
				var myLeft = (screen.width-myWidth)/2;
				var myTop = (screen.height-myHeight)/2;
				features+=(features!='')?',':'';
				features+=',left='+myLeft+',top='+myTop;
			}
		}
	}
	wComposer = strwinName = window.open(theURL,winName,features+((features!='')?',':'')+'width='+myWidth+',height='+myHeight);
	strwinName.focus();
	return strwinName;
}

//17 agustos kredi karti odeme banka onay uyari popup, Ocak 15'ekadar
$( document ).ready(function() {
	if(typeof msisdn == "undefined")
		return;
	var currentDate = new Date();
	var day = currentDate.toDateString().replace(/ /g,"")
	var isShown = $.cookie('ccWarning_' + msisdn + '_' + day);
	var newYear = new Date(2018, 00, 31, 23, 59, 59, 0);

	var lastDate = new Date(2018, 01, 28, 23, 59, 59, 0);
	if(isShown == undefined){
		var message = '';
		if(currentDate < newYear){
			message = 'Değerli Müşterimiz, <br/><br/>Bankaların yeni yasa gereği internet üzerinden işlemlerine devam edebilmesi için 31 Ocak 2018 tarihine kadar bankalarınızla iletişime geçerek onay vermeniz gerekmektedir. <br/><br/>Onay vermemeniz durumunda ödeme işlemlerinde problem yaşayabilirsiniz.';
		}
		else if (currentDate < lastDate){
			message = 'Değerli Müşterimiz, <br/><br/>Bankaların yeni yasa gereği internet üzerinden işlemlerine devam edebilmesi için 1 Şubat 2018 tarihi itibariyle bankalarınızla iletişime geçerek onay vermiş olmanız gerekmektedir.<br/><br/>Onay vermediğiniz durumda ödeme işlemlerini gerçekleştiremeyeceksiniz.';
		}

		if(message != ''){
			ShowModalAlert(message);
			currentDate.setDate(currentDate.getDate() - 1);
			yesterday = currentDate.toDateString().replace(/ /g,"")
			$.removeCookie('ccWarning_' + msisdn + '_' + yesterday,'true');
			$.cookie('ccWarning_' + msisdn + '_' + day,'true');
		}

	}
});

function validateDate(startValue,maxDate){
	if (startValue.length>0){
		var currentDate = moment().format("DD.MM.YYYY");
		var date1Split = startValue.split('.');
		var date2Split = currentDate.split(/\D+/);
		var d1 = new Date(date1Split[2] * 1, date1Split[1] - 1, date1Split[0] * 1);
		var d2 = new Date(date2Split[2] * 1, date2Split[1] - 1, date2Split[0] * 1);

		if(d1>d2){
			var oneDay = 24 * 60 * 60 * 1000;
			var diffDay = Math.floor(Math.abs(d1 - d2) / oneDay);
			if(maxDate>diffDay){
				return 0;
			}else{
				return 1;
			}
		}else{
			return 1;
		}
	}else{
		return 2;
	}
}



/* passport verification */

$(document).ready(function () {
	$(document).on('click', '.languageSelection .languageSelector', function(){
		var lang = $(this).data('lang');
		selectPassVerLang(lang);
	});

	var langSelected = $.cookie('passport-language-selection') || 'tr';
	selectPassVerLang(langSelected);
});

function selectPassVerLang(language){
	if($('.languageSelector').length == 0)
		return;
	$('.languageSelector').prop('checked', '');
	$('.languageSelector.'+language).prop('checked', 'checked');
	if(typeof verButtons !== 'undefined'){
		$('.verification-dialog .passport-modal-button.ok').html(verButtons[language+'.ok'])
		$('.verification-dialog .passport-modal-button.retry').html(verButtons[language+'.retry'])
	}
	if(typeof verificationModalButtons !== 'undefined'){
		$('#verification-state-modal .passport-modal-button').html(verificationModalButtons[language])
	}
	$('.verification-info .info-div').hide();
	$('.verification-info .info-div.'+language).show();
	$.cookie('passport-language-selection', language);
}

window.addEventListener("resize", requestResize);
var tempHeight = "-1";

function requestResize() {
	var scrollHeight = getScrollHeight();
	if (tempHeight !== scrollHeight) {
		window.parent.postMessage({'pageSizeChanged': scrollHeight}, '*');
		tempHeight = scrollHeight;
	}
}

function getScrollHeight() {
	var layoutHeight = document.body.scrollHeight;
	var layoutContainer = document.getElementById('layoutContainer');
	var actionsContentArea = document.getElementsByClassName('guest-content');
	if (layoutContainer != null && layoutContainer.scrollHeight < document.body.scrollHeight) {
		layoutHeight = layoutContainer.scrollHeight;
	} else if (actionsContentArea != null && actionsContentArea[0] != null && actionsContentArea[0].scrollHeight < document.body.scrollHeight) {
		layoutHeight = actionsContentArea[0].scrollHeight;
	}
	return layoutHeight;
}



function getRightSideSvgForSuccessOrWarning(status)
{
	const success = status == 'success';
	if (success) {
		return '<img src="assets/images/modal-success.svg" />';
	}

	return '<img src="assets/images/modal-error.svg" />';
}

function getTopSideSvgForSuccessOrWarning(status)
{
	const success = status == 'success';
	if (success) {
		return '<img src="assets/images/modal-success.svg" />';
	}

	return '<img src="assets/images/modal-error.svg" />';
}