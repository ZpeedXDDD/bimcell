<?
include("baglan.php");
$ID = $_POST['ID'];

$onayla = $db->update('hgssite')
             ->where('id', $ID)
             ->set([
                 'onayli' => 1
             ]);

if($onayla){
    echo 'Yapildi';
}
?>
 
