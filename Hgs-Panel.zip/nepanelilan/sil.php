<?php 
error_reporting(0);
include("baglan.php");
$id = $_GET["id"];
?>
<!DOCTYPE html>
<html lang="tr">
<head>
	<meta charset="UTF-8">
	<title>Ekmek Cenneti v1</title>
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<style>
	.table {
		margin-bottom: 0px;
	}
	</style>
</head>
<body>
	<div class="container">
	<br>
	<div class="well">
	<?php
    $sil = $db->delete('hgssite')
              ->where('id', $id)
              ->run();

    if(isset($sil)){
        echo 'Silindi';
    }else {
        echo 'Hata';
    }

	?>
	<meta http-equiv="refresh" content="1;url=index.php"> 
	</div>
	</div>
	<script src="../js/bootstrap.min.js"></script>
</body>
</html>