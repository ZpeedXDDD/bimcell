<?php
error_reporting(0);
include("baglan.php");
session_start();
if($_SESSION['logged'] != "1") {
    echo "<meta http-equiv='refresh' content='0;url=giris.php'>";
    die(); }
?>
<!DOCTYPE html>
<html lang="tr">
<head>
	<meta charset="UTF-8">
	<title>HGS PANEL</title>
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<style>
	.table {
		margin-bottom: 0px;
	}
	</style>
<script>
function sendRating(rating, reload_on_return) {

$.ajax({
    type: "POST",
    dataType: 'json',
    url: window.url_root + cid + "/",
    async: false,
    data: {
        "rating": rating.r2 / 100.0
    },
    success: function(data) {
        if (data.hasOwnProperty('success')) {
            console.log("data was sent!");

            if (reload_on_return) {
                setTimeout(
                  function() 
                  {
                     location.reload();
                  }, 0001);    
            }

        }
    },
    error: function() {
        console.log("Data didn't get sent!!");
    }
})
</script>
	<script
			  src="https://code.jquery.com/jquery-3.2.1.min.js"
			  integrity="sha256-hwg4gsxgFZhOsEEamdOYGBf13FyQuiTwlAQgxVSNgt4="
			  crossorigin="anonymous"></script>
	<script>
 $(document).ready(function() {
     $("#yenile2").load("yenile.php");
   var refreshId = setInterval(function() {
      $("#yenile2").load('yenile.php?randval='+ Math.random());
   }, 5000);
});
</script>
</head>
<body>
<div id="yenile2"></div>
	<script src="../js/bootstrap.min.js"></script>
</body>
</html>