<?php

require 'lib/BasicDB.php';
session_start();

$ayarlar['host'] = 'localhost';
$ayarlar['dbname'] = 'hgs_data';
$ayarlar['user'] = 'hgs_data';
$ayarlar['pass'] = 'ykfmbub4G';

$db = new Erbilen\Database\BasicDB($ayarlar['host'], $ayarlar['dbname'], $ayarlar['user'], $ayarlar['pass'])
?>