﻿<meta charset="utf-8">
<?php
$link = mysql_connect("localhost", "hgs_data", "ykfmbub4G");
 
$db = mysql_select_db("hgs_data", $link);
if($db){
    }
else {
        echo "Veritabanına bağlantı sağlanamadı";
    }
?>