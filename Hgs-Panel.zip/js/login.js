$(document).ready(function() {
	$('#newmember_form input').click(function() {
		$('#newmember_alert').html('');
		$('#newmember_alert').hide();
	});

	$('#newmember_form').keyup(function(e){
		if(e.keyCode == 27){
			resetNewMemberForm();
		}
	});

	$('#frm_uyeol input').click(function() {
		if($('#frm_uyeol_error').val() == $(this).attr('id')){
			$(this).val('');
			$(this).removeClass('input-error');
			$('#frm_uyeol_error').val('0');
			$('img.'+$(this).attr('id')).fadeOut(200);

			if($(this).attr('data')){
				$(this).val($(this).attr('data'));
				$(this).attr('data','0');
			}
		}
	});

	$('.uyelik_sozlesme').click(function(){
		var check = $(this).attr('checked');
		if(check == "checked"){
			$('#btn-utamamla').removeClass('opacity');
			$('#btn-utamamla').removeAttr('disabled');
		}else{
			$('#btn-utamamla').addClass('opacity');
			$('#btn-utamamla').attr('disabled','disabled');
		}
	});

	$('#passnew').keyup(function(){
		$(this).prop('type','password');
	});

	$('#frm_uyeol input').keyup(function() {
		if($('#frm_uyeol_error').val() == $(this).attr('id')){
			$(this).val('');
			$(this).removeClass('input-error');
			$('#frm_uyeol_error').val('0');
			$('img.'+$(this).attr('id')).fadeOut(200);

			if($(this).attr('data')){
				$(this).val($(this).attr('data'));
				$(this).attr('data','0');
			}
		}
	});


	// Üye ol penceresi
	// $('#btn-register').click(function(e) {
     //    event.preventDefault();
     //    $('#frm_uyeol').iziModal('open');
	// });

	// Login penceresi


	$(document).keyup(function(e) {
		if (e.keyCode == 27) {
			newMemberCancel();
			clearFrmLogin();
		}
	});

	/*$('#newmember_form').keyup(function(e) {
	 if (e.keyCode == 13) {
	 newMemberSave();
	 }
	 });*/

	$('#frm_login').keyup(function(e) {
		if (e.keyCode == 13) {
			login();
		}
	});

	$('.privacy').click(function() {
		var val = $(this).val();
		if (val == 1) {
			$(this).val(0);
			$('.newmember button').addClass('opacity');
			$('.newmember button').attr('disabled', 'disabled');
		} else {
			$(this).val(1);
			$('.newmember button').removeClass('opacity');
			$('.newmember button').removeAttr('disabled');
		}
	});

	$("#btn-sgonder").on("click", function () {
		if(isEmail($("#passmail").val())) {
			forgotPwd();
		} else {
			$("#passmail").addClass("input-error");
			$(".passemail-message").text("Lütfen geçerli bir e-posta adresi giriniz").fadeIn();
		}
	});

	$('#sifremiunuttum #passmail').on("focus",function(){
		$(".passemail-message").fadeOut();
		$('#sifremiunuttum #passmail').removeClass('input-error');
	});
});

function newMemberShow() {
	$('.notmember').hide();
	$('.loginform').css('opacity', '0.1');
	$('.loginform input').attr('disabled', 'disabled');
	$('.loginform button').attr('disabled', 'disabled');
	$('.newmember').show();
}

function newMemberCancel() {
	$('.notmember').show();
	$('.loginform').css('opacity', '1');
	$('.loginform input').removeAttr('disabled');
	$('.loginform button').removeAttr('disabled');
	$('.newmember').hide();
	$('#newmember_alert').hide();
	$('#newmember_form input').each(function(a, b) {
		$(b).val('');
	});
}

jQuery.fn.serializeAndEncode = function() {
	return escape(this.serialize());
};

$(document).on("focus", '#newmember_form input', function () {
	$(this).siblings(".error.message").fadeOut();
});

function formElementControl($inputs, $form) {
	var validCount = 0;
	for (var i =0; i< $inputs.length; i++) {
		var inputElem = $($form).find("[name=" + $inputs[i] + "]");
		if($(inputElem).val() == "") {
			$("." + $inputs[i] + "-error").text($(inputElem).attr("data-message")).fadeIn();
			validCount++;
		}
	}
	if (validCount > 0)
		return false;
	else {
		return true;
	}
}

function newMemberSave() {
	var $inputs=["name", "surname", "tckno", "email", "username", "pass"];
	if(!formElementControl($inputs, "#newmember_form"))
		return false;

	if(!isEmail($("#newmember_form [name=email]").val())) {
		$("#newmember_form [name=email]").siblings(".email-error").text("Lütfen geçerli bir e-posta adresi giriniz").fadeIn()
		return false;
	}

	$('.loader_uyeol').show();
	$('#newmember_form').attr('class', 'opacity');
	$.ajax({
		url : '/api/newhgsmember',
		type : 'GET',
		dataType : 'json',
		data : $('#newmember_form').serialize(),
		success : function(obj) {
			var msg = obj.message;
			var success = obj.success;
			var code = obj.code;
			$('.loader_uyeol').hide();
			$('#newmember_form').removeAttr('class');
			if (!success) {
				$('#frm_uyeol_error').val(code);
				$('#'+code).attr('data',$('#'+code).val());
				$('#'+code).addClass('input-error');
				$('.'+code + "-error").text(msg).fadeIn(200);
			} else {
				$('.sendmail').html($('#email').val());
				$('#frm_uyeol form').hide();
				$('#frm_uyeol .notices .notice-text').html(msg);
				$('#frm_uyeol .notices').fadeIn(200);
			}
		}
	});
}

function loginNotMember() {
	$('#ic-login-loader').show();
	$.ajax({
		url : '/api/notmember',
		type : 'POST',
		dataType : 'json',
		data : "control=1",
		success : function(result) {
			location.reload();
		}
	});
}

$(document).on("focus", '#frm_login input', function () {
	if($(this).hasClass("input-error")) {
		$(this).removeClass("input-error")
		$(this).parent(".input-control").next(".error.message").fadeOut();
	}
});

function login() {
	var isValid = 0;
	if($("#user").val().trim().length == 0) {
		$(".user-message").text("Kullanıcı adı veya e-posta adresi boş bırakılamaz").fadeIn();
		$("#user").addClass("input-error");
		isValid++;
	}
	if($("#pass").val().trim().length == 0) {
		$(".pass-message").text("Şifrenizi girin").fadeIn();
		$("#pass").addClass("input-error");
		isValid ++;
	}
	if(isValid > 0)
		return false;
	$('#login-loader').show();
	$('#frm_login').addClass('opacity');
	$.ajax({
		url : '/api/login',
		type : 'GET',
		dataType : 'json',
		data : $('#frm_login').serialize(),
		success : function(obj) {
			var msg = obj.message;
			var success = obj.success;
			var type = obj.error_type;
			if (success) {
				location.reload();
			} else {
				$('#login-loader').hide();
				$('#frm_login').removeClass('opacity');
				if (type == "user") {
					$('#frm_login #error').attr('value', 1);
					$('#user').attr('class', 'input-error');
					$('.user-message').text(msg).fadeIn();
				} else if (type == "pass") {
					$('#frm_login #error').attr('value', 2);
					$('#pass').attr('class', 'input-error');
					$('.pass-message').fadeIn();
				} else if (type == "userpass") {
					$('#frm_login #error').attr('value', 3);
					$('#pass, #user').attr('class', 'input-error');
					$('.pass-message').text("Lütfen şifrenizi giriniz").fadeIn();
					$('.user-message').text("Lütfen kullanıcı adınızı giriniz").fadeIn();
				}
			}
		}
	});
}

function clearFrmLogin() {
	if ($('#frm_login #error').val() == 1) {
		$('#frm_login #user').val('');
		$('#frm_login #error').val('0');
	} else if ($('#frm_login #error').val() == 2) {
		$('#frm_login #pass').val('');
		$('#frm_login #error').val('0');
	} else if ($('#frm_login #error').val() == 3) {
		$('#frm_login #pass').val('');
		$('#frm_login #user').val('');
		$('#frm_login #error').val('0');
	}
	$('#frm_login input').removeAttr('class');
	$('.user-message, .pass-message').fadeOut();
}

function showDialog(content,width,height,opdlg, extra_css){
    $('#general_modal .iziModal-wrap .iziModal-content').html(content);

    setTimeout(function() {
        $('#general_modal').iziModal('open');
    }, 100);
}

// function showDialog(content,width,height,opdlg, extra_css){
// 	$('#alertDialog').find('span').html(content);
// 	if(width){
// 		$('#alertDialog').css('width',width+'px');
// 	}else{
// 		$('#alertDialog').css('width','auto');
// 	}
// 	if(height){
// 		$('#alertDialog').css('height',height+'px');
// 	}else{
// 		$('#alertDialog').css('height','auto');
// 	}
// 	if(extra_css)
// 	{
// 		for (i in extra_css)
// 		{
// 			if (!extra_css.hasOwnProperty(i))
// 				continue;
// 			$('#alertDialog').css(i, extra_css[i]);
// 		}
// 	}
// 	$('#alertDialog').jOverlay({color: 'white', opacity: 0.8});
// 	if(opdlg){
// 		$('#alertDialog .close').attr('onclick',"$.closeOverlay();$('#"+opdlg+"').jOverlay({color: 'white', opacity: 0.6});");
// 	}
// }
//




function resetNewMemberForm(){
	$('#frm_uyeol form').show();
	$('#newmember_form')[0].reset();
	$('#frm_uyeol .notices').hide();
	$('#newmember_form input[type=checkbox]').removeAttr('checked');
	$('#btn-utamamla').addClass('opacity');
}

function forgotPwd(){
	$('#sifremiunuttum #ic-sunuttum').show();
	$('#sifremiunuttum #btn-sgonder').attr('disabled','disabled');
	$.ajax({
		url : '/api/forgotpwd',
		type : 'GET',
		dataType : 'json',
		data : $('#frmpwd').serialize(),
		success : function(obj) {
			$('#sifremiunuttum #ic-sunuttum').hide();
			var success = obj.success;
			var msg = obj.message;
			if(!success){
				$('#sifremiunuttum #passmail').addClass('input-error');
				$('#sifremiunuttum #passmail').attr('ftext',$('#sifremiunuttum #passmail').val());
				$(".passemail-message").text(msg).fadeIn();

			}else{
				$('#sifremiunuttum form').hide();
				$('#sifremiunuttum form')[0].reset();
				$('#sifremiunuttum #gonderildi').find("b").text(msg);
				$('#sifremiunuttum #gonderildi').fadeIn('slow');
			}
		},
		complete: function () {
			$('#sifremiunuttum #ic-sunuttum').hide();
			$('#sifremiunuttum #btn-sgonder').removeAttr('disabled');
		}
	});
}

function isEmail(email) {
	var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	return regex.test(email);
}