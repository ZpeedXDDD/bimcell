$(document).ready(function() {

	$('.widget-container').height('470px');

	$('.icon').on('click', function(e){
		e.preventDefault();
		if ($('.icon').hasClass('glyphicon-hand-up')) {
			$('.widget-container').height('470px');
			$('.icon').removeClass('glyphicon-hand-up').addClass('glyphicon-hand-down');
		} else {
			$('.widget-container').height('60px');
			$('.icon').removeClass('glyphicon-hand-down').addClass('glyphicon-hand-up');
		}
	});

	$('.moda-konseptt').on('click', function(){
		_gaq.push(['_trackEvent', 'HGS', 'Widget', "Moda Konseptt"]);
	});

	$('.widget-campaign').on('click', function(){
		_gaq.push(['_trackEvent', 'HGS', 'Widget', "oto-aksesuar/oto-lastigi/?details=30486"]);
	});
});