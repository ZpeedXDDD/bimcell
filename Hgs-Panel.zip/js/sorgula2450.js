var phishingAlertShown = 0;
function customerAlertPhishing() {
    /**
     * Uyarı devre dışı bırakılmıştır.
     * Can Yildiz @ 2016-08-01 16:25
     */
    return false;
    if(phishingAlertShown === 1)
        return false;
    var text = '<p style="text-align:center;"><strong>HGS Kullanıcılarının Dikkatine, </strong></p>'
        +'<p style="text-align:center;">PTT’den alınmış olan HGS ürünlerinize internet üzerinden sadece <strong>hgs.epttavm.com</strong>  adresinden ve HGS mobil uygulama üzerinden yükleme yapılmaktadır. </p>'
        +'<p style="text-align:center;"><strong>hgs.epttavm.com </strong>haricinde farklı sitelerden yapılan yüklemeler dolandırıcılık amacı ile açılmış olup itibar etmemeniz konusunda tüm kullanıcıları uyarmak isteriz. </p>'
        +'<p style="text-align:center;">Yasal HGS yüklemesi yapılan hgs.epttavm.com sayfasının adres çubuğunda Posta ve Telgraf Teşkilatı A.S Genel Mudurluğu (PTT) ibareli SSL sertifikası bulunmaktadır.</p>'
        +'<p style="text-align:center;">Bu <strong>SSL </strong>sertifikasına sahip olmayan sitelere itibar etmeyiniz. </p>'
        + '<div style="text-align:center;"><img style="position:relative; top: 10px; bottom:40px; max-width:100%;" src="/img/hgs_login_popup.png" /></div>';
    showDialog(text, null, null, null, {'top':'37%'});
    phishingAlertShown = 1;
}

function loadingPayment () {
    var text = '<div id="paymentProgress"><p style="text-align:center;"><strong>İşleminiz Devam Ediyor. Lütfen Bekleyin.... </strong></p></div>';

    showDialog(text, null, null, null, {'top':'37%'});
}

function creditCardValidation (value) {
    if (/[^0-9-\s]+/.test(value)) return false;

    var nCheck = 0, nDigit = 0, bEven = false;
    value = value.replace(/\D/g, "");

    for (var n = value.length - 1; n >= 0; n--) {
        var cDigit = value.charAt(n),
            nDigit = parseInt(cDigit, 10);

        if (bEven) {
            if ((nDigit *= 2) > 9) nDigit -= 9;
        }

        nCheck += nDigit;
        bEven = !bEven;
    }

    return (nCheck % 10) == 0;
}

$(document).ready(function() {
    $("#btn-load").on('click', function(e){
        e.preventDefault();

        var error = 0;
        $('.form-validate').each(function(){
            var val = $(this).val();
            if (val == "") {
                $(this).addClass('input-error');
                showDialog("Lütfen tüm alanları eksiksiz doldurunuz.", '', '');
                error += 1;
            } else {
                $(this).removeClass('input-error');
                error -= 1;
            }
        });

        var cardNumber = $("input[name=ccno1]").val() + $("input[name=ccno2]").val() + $("input[name=ccno3]").val() + $("input[name=ccno4]").val();
        var isCardValid = creditCardValidation(cardNumber);

        if (isCardValid == false) {
            error = 1;
            showDialog("Girmiş olduğunuz kredi kartı numarası geçersizdir. Lütfen tekrar deneyin.", '', '');
        }

        if (error <= 0) {
            var price = $(".miktarlar").find("div.item-active").data("price");
            var hgs_id = $("#stickerList").find("div.darkorange").find("span.etiketno").attr('rel');
            var plateNo = $("#plateNo").val();
            var commission =  parseInt($(".miktarlar").find("div.item-active").data("commission"))

            if (commission == 0) {
                $("#confirm").find("#komisyon").hide();
            } else {
                $("#confirm").find("#komisyon").html('<b>' + commission + " TL</b> hizmet bedeli ile,").show();
            }

            $("#confirm").find("#bedel").html(price + " TL");
            $("#confirm").find("#hgs_no").html(hgs_id);
            $("#confirm").find("#plate_no").html(plateNo);
            $('#confirm').iziModal('open');
        }
    });

    $('#username').bind('keyup', function(){
        $(this).val(trkontrol($(this).val()));

        $(this).val($(this).val().replace(/\s+/g, ''));
    });

    // FeedBack Button Animation
    $('#feedback_leftbtn').mouseover(function(){
        $(this).stop().animate({left: '-12px'},300);
    });

    $('#feedback_leftbtn').mouseout(function(){
        $(this).stop().animate({left: '-25px'},300);
    });




    //feedback alternatif

    $('#feedback_leftbtnx').mouseover(function(){
        $(this).stop().animate({left: '-12px'},300);
    });

    $('#feedback_leftbtnx').mouseout(function(){
        $(this).stop().animate({left: '-25px'},300);
    });

    $('#feedback_leftbtnxx img').click(function(){
        $('#frm_iletisim').iziModal('open');
    });


    $("#req_type").selectbox({
        effect: "fade"
    });

    $('#lnk-contact').click(function() {
        $('#frm_iletisim form')[0].reset();
        $('#frm_iletisim form').show();
        $('#frm_iletisim .notices').hide();
        $('#frm_iletisim').iziModal('open');
        // $('#iletisim_tel').mask("0(999) 999-9999");
    });

    $('#tckno_error').click(function() {
        $(this).val('');
        $(this).hide();
        $('#tckno_new').show();
        $('#tckno_new').select();
    });

    $('#btn-tckno-ok').click(function() {
        /*$.closeOverlay();
         $('#hgs-sorgula').submit();
         $('#user_tckno').val('1');*/
        location.reload();
    });

    /*$('#frm_iletisim form').keyup(function(e) {
     if (e.keyCode == 13) {
     contactFormSave();
     }
     });*/

    $('#iletisim_tel').mask("0(999) 999-9999");

    $('#frm_iletisim form input, #frm_iletisim form textarea').focus(function() {
        if($(this).hasClass("input-error")) {
            $(this).val('');
            $(this).removeClass('input-error');
            $('img.' + $(this).attr('id')).fadeOut(200);
        }
    });

    $('#alt_sagreklam a').mouseover(function() {
        $('#alt_sagreklam a').find('button').hide();
        $(this).find('button').show();
    });

    $('#btn-odeme').click(function() {
        $("#hidden2").hide();
        $('html, body').animate({
            scrollTop: $(".odeme").offset().top - 50
        }, 600);
        return false;
    });

    $('.miktarlar .item').click(function() {
        $('#btn-odeme').removeClass('opacity');
        $('#btn-odeme').removeAttr('disabled');
    });

    $('.hizli_islem .hislem').click(function() {
        if ($('#hizli_islemadi').css('display') == "none") {
            $(this).attr('checked', 'checked');
            $('#hizli_islemadi').show();
        } else {
            $(this).removeAttr('checked');
            $('#hizli_islemadi').hide();
            $('#hizli_islemadi').attr('value', '');
        }
    });

    function getUserCommission() {
        $.ajax({
            url: '/api/commission&user=' + $('#user_id').val(),
            type: 'POST',
            dataType: 'json',
            beforeSend: function () {
              $("#panel .aciklama .loading").show();
            },
            success: function(obj) {
                var price = obj.price;
                var minus = obj.minus;
                if (price < 100) {
                    $('#panel .tutarlar .aciklama').find('.daha').show();
                }
                $('#panel .tutarlar .t1').html(price + ' TL');
                $('#panel .tutarlar .t2').html(minus + ' TL');
            },
            complete: function () {
                $("#panel .aciklama .loading").hide();
            }
        });
    }

    $('#welcome .altok').click(function() {
        getUserCommission();
    });

    $('#welcome div').click(function() {
        getUserCommission();
    });

    /*$('#btn-kyukle').click(function() {
     $('html, body').animate({
     scrollTop: $("#odemeonay").offset().top - 60
     }, 600);
     return false;
     });*/

    $('.kkart').click(function() {
        if ($('#kcheck').val() == 1) {
            $(this).removeAttr('checked');
            $('#kcheck').attr('value', '0');
            $('.kredikarti div').addClass('opacity');
            $('.kredikarti form').find('input').val('');
            $('#pay_type').val('0');
        } else {
            $('.kredikarti .opacity').removeClass('opacity');
            $('#kcheck').attr('value', '1');
            $(this).attr('checked', 'checked');
            $('.havale div').addClass('opacity');
            $('.hvl').removeAttr('checked');
            $('#hcheck').attr('value', '0');
            $('#pay_type').val('1');
            $('.havale #btn-hyukle').hide();
            $('.kredikarti #btn-kyukle').show();
            $('.kredikarti #yloader2').hide();
        }
    });

    $('.hvl').click(function() {
        if ($('#hcheck').val() == 1) {
            $(this).removeAttr('checked');
            $('#hcheck').attr('value', '0');
            $('.havale div').addClass('opacity');
            $('#pay_type').val('0');
        } else {
            $('.kredikarti #yloader1').hide();
            $('.havale .opacity').removeClass('opacity');
            $('.kkart').removeAttr('checked');
            $('#kcheck').attr('value', '0');
            $('.kredikarti div').addClass('opacity');
            $('#hcheck').attr('value', '1');
            $(this).attr('checked', 'checked');
            $('#pay_type').val('2');
            $('.havale #btn-hyukle').show();
            $('.kredikarti #btn-kyukle').hide();
        }
    });

    $('button#btn-sorgula').click(function() {
        /* $('html, body').animate({
         scrollTop: $("#etiketler").offset().top
         }, 600);
         return false;*/
    });

    $('.miktarlar .item').click(function() {

        $('.miktarlar .item').removeClass('item-active');
        $('.miktarlar .item').removeAttr('id');

        $(this).addClass('item-active');
        $(this).attr('id', "active");

    });



    /* ajax request */
    $("#hgs-sorgula").submit(function() {
        customerAlertPhishing();
        var tckno = $('#user_tckno').val();
        var plateNo = $("#plateNo");
        var query = plateNo.val().replace(/[^a-zA-Z0-9]/g, '');
        var reqType = $("#req_type").val();
        var user_id = $("#user_id").val();
        var still_ajax = $("#still_ajax").val();
        if (tckno == 0 && user_id > 0) {
            $('#tckno-hata').iziModal('open');
            return false;
        } else {
            if (query.length < 6 || query.length > 11) {
                showDialog("Sorgulama alanına TC Kimlik No, Plaka, Vergi No veya Pasaport No giriniz.", '', '');
                return false;
            }
            if ($("#ajax_again").val() == plateNo.val()) {
                showDialog("Aynı bilgileri üst üste sorgulayamazsınız", '', '');
                return false;
            }
            var uyari = "";
            if (user_id > 0) {
                uyari = "epttavm.com'a üye olurken girdiğiniz T.C. Kimlik No ile sorguladığınız HGS ürününün bağlı olduğu T.C. Kimlik numarası uyuşmamaktadır";
            } else {
                uyari = "Bakiye görüntüleyebilmek için sorguladığınız ürün ile ilişkili TC Kimlik Numarasına sahip hesabınızla giriş yapmalısınız.";
            }
            $('#ic-sorgula').attr('src', 'img/loader-green.gif');
            $(".remove-sticker").remove();
            resetAll(false);
            $("#still_ajax").val('1');
            $.ajax({
                url: "hgs/hgs/lookup/" + query + "/" + reqType + "/" + user_id,
                dataType: 'json',
                headers: {
                    'X-Epa-Request-Id': 'web.v2.' + Math.floor(Date.now() / 1000),
                    'X-Epa-Service': 'epttavm',
                    'X-Epa-Timestamp': TIMESTAMP,
                    'X-Epa-Hash': HASH
                },
                success:function(data) {
                    if (data.code == 200) {
                        $("#ajax_again").val(plateNo.val());
                        $('#ic-sorgula').attr('src', 'img/ic-sorgula.png');
                        $.each(data.products, function(code, product) {
                            var aktif = (product.productStatus == "Aktif") ? "" : "pasif-item";

                            var amount = (product.saleAmount == "xx") ? '<img src="img/unlem.png" class="unlem vtip" title="' + uyari + '" alt="" />' : product.saleAmount + " TL";
                            var sticker = $('<div class="data remove-sticker ' + aktif + '">\n\
                        <span class="etiketno" rel="' + product.productNo + '">' + maskHGS(product.productNo) + '</span>\n\
                        <span class="plaka">' + product.plateNumber + '</span>\n\
                        <span class="sinif">' + product.vehicleClass + '. Sınıf</span>\n\
                        <span class="bakiye">' + amount + '</span>\n\
                        <span class="secbuton"><input type="button" value="Seç" /></span>\n\
                        </div>');
                            sticker.click(function() {
                                if ($(this).hasClass('pasif-item')) {
                                    showDialog("Bu ürün iptal edilmiş. <br />Bir yanlışlık olduğunu düşünüyorsanız PTT şubesine başvurun.", '', '');
                                    return false;
                                } else {
                                    $('.data').removeClass('darkorange');
                                    $(this).addClass('darkorange');
                                    $('.yuklememiktari .hidden').hide();
                                    $('.miktarlar .item').css('cursor', 'pointer');
                                    $("#hgs_id").val($(this).children('.etiketno').attr('rel'));
                                    $('html, body').animate({
                                        scrollTop: $(".yuklememiktari").offset().top - 90
                                    }, 600);
                                    return false;
                                }
                            });

                            $("#stickerList").append(sticker);
                        });
                        paketGuncelle();
                        $('html, body').animate({
                            scrollTop: $("#etiketler").offset().top
                        }, 600);

                    } else if (data.code == 700) {
                        showDialog(data.products, '', '');
                        $('#ic-sorgula').attr('src', 'img/ic-sorgula.png');
                        return false;
                    }
                },
                error: function (jqXHR, exception) {
                    if(jqXHR.status === 500) {
                        showDialog("HGS sistemine bağlanılamadı. Kısa bir süre sonra tekrar deneyiniz", '', '');
                    } else if(jqXHR.status === 404) {
                        showDialog("Bilgileriniz sistemde bulunamadı.<br />Lütfen girdiğiniz bilgilerin doğruluğundan emin olun", '', '');
                    }else if(jqXHR.status === 0) {
                        showDialog("HGS sistemine bağlanılamadı. Kısa bir süre sonra tekrar deneyiniz", '', '');

                    } else if(jqXHR.status === 401) {
                        showDialog("Geçersiz işlem. Lütfen daha sonra tekrar deneyiniz", '', '');
                    } else {
                        showDialog("HGS sistemine bağlanılamadı. Kısa bir süre sonra tekrar deneyiniz", '', '');
                    }
                },
                complete: function() {
                    $('#ic-sorgula').attr('src', 'img/ic-sorgula.png');
                    vtip();
                    $("#still_ajax").val('0');
                }
            });
        }
        return false;
    });

    $(".item").click(function() {
        var price = parseFloat($(this).attr('data-price'));
        var commission = parseFloat($(this).attr('data-commission'));
        var total = parseFloat(price) - parseFloat(commission);

        $("form[name='payment-form'] input.hgs-products").val($(this).attr('rel'));
        $("#hgsyukleme").html(price + ' TL');
        $("#hizmetbedeli").html(commission + ' TL');
        $("#tbedel").html(total + ' TL');

    });

    $('#kkform').keyup(function(e) {
        if (e.keyCode == 13) {
            chargeHgs();
        }
    });
    $("#btn-kyukle").click(function() {
        chargeHgs();
    });
    $('#eftform').keyup(function(e) {
        if (e.keyCode == 13) {
            chargeEft();
        }
    });
    $("#btn-hyukle").click(function() {
        chargeEft();
    });

    $('.ccno').keypad({
        prompt: '', keypadOnly: false,
        layout: ['123',
            '456',
            '789',
            '0' + $.keypad.CLEAR],
        showAnim: '',
        showOptions: null,
        duration: 'fast',
        onKeypress: function(key, value, inst) {
            var $id = $(this).attr('id');
            if ($id != "cv2") {
                if ($(this).val().length == 4) {
                    if ($id != "ccno4") {
                        $(this).trigger('blur');
                        $(this).parent('.kartno').next('.kartno').children('.ccno').focus();
                    } else {
                        $(".ccno").keypad('hide');
                    }
                } else if ($(this).val().length > 4) {
                    $(this).maksKarakter(4);
                    $(this).parent('.kartno').next('.kartno').children('.ccno').focus();
                }
            } else {
                if ($(this).val().length == 3) {
                    $(".ccno").keypad('hide');
                } else if ($(this).val().length > 3) {
                    $(this).maksKarakter(3);
                }
            }
        }
    });


    $('.ccno').keyup(function(e) {
        var $id = $(this).attr('id');
        if ($id != "cv2") {
            if ($(this).val().length == 4) {
                if ($id != "ccno4") {
                    $(this).trigger('blur');
                    $(this).parent('.kartno').next('.kartno').children('.ccno').focus();
                } else {
                    $(".ccno").keypad('hide');
                }
            } else if ($(this).val().length > 4) {
                $(this).maksKarakter(4);
                $(this).parent('.kartno').next('.kartno').children('.ccno').focus();
            }
        } else {
            if ($(this).val().length == 3) {
                $(".ccno").keypad('hide');
                $(this).blur();
            } else if ($(this).val().length > 3) {
                $(this).maksKarakter(3);
            }
        }
    });

    $(".ccno").keydown(function(event) {
        if (event.keyCode == 46 || event.keyCode == 8 || event.keyCode == 9 || event.keyCode == 27 || event.keyCode == 13 ||
            (event.keyCode == 65 && event.ctrlKey === true) ||
            (event.keyCode >= 35 && event.keyCode <= 39)) {
            return;
        }
        else {
            if (event.shiftKey || (event.keyCode < 48 || event.keyCode > 57) && (event.keyCode < 96 || event.keyCode > 105)) {
                event.preventDefault();
            }
        }
    });


    $("#plateNo").on('keypress', function() {
        $(this).removeClass('soluk');
    });
    $("#plateNo").on('click', function() {
        var value = $(this).val();
        if (value == "06 EPTT 06") {
            $(this).removeClass('soluk');
            $(this).val('');
        }
    });
    $("#req_type").change(function() {
        $("#plateNo").val('').focus();
        $(this).removeClass('soluk');

        var thisVal = $(this).val();
        if(thisVal == 0) {
            $('#plateNo').attr('placeholder', '06 EPTT 06')
        } else if(thisVal == 1) {
            $('#plateNo').attr('placeholder', 'TC kimlik no girin...')
        } else if(thisVal == 2) {
            $('#plateNo').attr('placeholder', 'Vergi no girin...')
        } else if(thisVal == 3) {
            $('#plateNo').attr('placeholder', 'Pasaport no girin...')
        } else if(thisVal == 4) {
            $('#plateNo').attr('placeholder', 'HGS ürün no girin...')
        }
    });

    $(".dropdown img.flag").addClass("flagvisibility");

    $(".dropdown dt a").click(function() {
        $(".dropdown dd ul").toggle();
    });

    $(".dropdown dd ul li a").click(function() {
        var text = $(this).html();
        $(".dropdown dt a span").html(text);
        $(".dropdown dd ul").hide();
        $("#result").html("Selected value is: " + getSelectedValue("sample"));
    });

    function getSelectedValue(id) {
        return $("#" + id).find("dt a span.value").html();
    }

    $(document).bind('click', function(e) {
        var $clicked = $(e.target);
        if (!$clicked.parents().hasClass("dropdown"))
            $(".dropdown dd ul").hide();
    });


    $("#flagSwitcher").click(function() {
        $(".dropdown img.flag").toggleClass("flagvisibility");
    });


});

$.fn.maksKarakter = function(uzunluk) {
    var deger = $(this).val();
    var strn = "";
    for (i = 0; i < uzunluk; i++) {
        strn += deger[i];
    }

    $(this).val(strn);
}

function maskHGS(hgs) {
    return "****"+hgs.substr(4);
}

function chargeHgs(confirm) {
    if (!confirm) {
        if ($("#ccOwner").val() == "") {
            showDialog("Lütfen kart sahibinin adını giriniz", '', '');
            return false;
        }
        if ($("#ccno1").val().length < 4 || $("#ccno2").val().length < 4 || $("#ccno3").val().length < 4 || $("#ccno4").val().length < 4) {
            showDialog("Lütfen kart numarasını 16 haneli olarak giriniz", '', '');
            return false;
        }
        if ($("#cv2").val().length < 3) {
            showDialog("Lütfen güvenlik kodunu giriniz", '', '');
            return false;
        }
        if ($('#user_id').val() == 0) {
            if ($("#non_user_email").val().length > 0) {
                var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
                if (!filter.test($("#non_user_email").val())) {
                    showDialog("E-posta adresi yanlış.<br /> Lütfen kontrol edin", '', '');
                    return false;
                }
            }
        }

        var bedel = $('.item-active').attr('data-price');
        var hgsno = $('#hgs_id').val();
        //var s = confirm(bedel + " TL bedelin, " + hgsno + " no'lu HGS ürününe yüklenmesini onaylıyor musunuz ? \n\nOnline HGS dolum ücretlerine ait iade/iptal mümkün değildir.");
        $('#bedel').html(bedel + ' TL');
        $('#hgs_no').html(hgsno);

        $('#confirm').iziModal('open');
        return false;
    } else {
        $.closeOverlay();
        var firstname = $("#ccOwner").val();
        var ccno = $("#ccno1").val() + $("#ccno2").val() + $("#ccno3").val() + $("#ccno4").val();
        var cv2 = $("#cv2").val();
        var cc_expire = $("#ccYear").val() + $("#ccMonth").val();
        var user_mail = "no-mail";
        if ($('#user_id').val() > 0) {
            user_mail = $("#user_email").val();
        } else {
            if ($("#non_user_email").val().length > 0) {
                user_mail = $("#non_user_email").val();
            }
        }

        var jdata = '{"firstname":"' + firstname + '","type": "1","source": "2","user_id": "' + $('#user_id').val() + '","hgs_id": "' + $('#hgs_id').val() + '","email": "' + user_mail + '","cc_number":"' + ccno + '","cc_cvv":"' + cv2 + '","cc_expires":"' + cc_expire + '","products":["' + $("#products").val() + '"]}';

        $('#yloader1').show();
        $('#etiketler .kredikarti .hidden').show();
        $.ajax({
            url: 'hgs/hgs/submit',
            dataType: 'json',
            data: jdata,
            type: "POST",
            success: function(data) {
                $('#etiketler .kredikarti .hidden').hide();
                $('#yloader1').hide();
                if (data.code == 200) {
                    /*$("#odemeonay").show();
                     resetAll();
                     $('html, body').animate({
                     scrollTop: $("#odemeonay").offset().top - 60
                     }, 600);
                     paketGuncelle();*/

                    location.href = "http://www.epttavm.com/my/odeme_sonuc.php?hqpm=web&rfn="+data.reference_id+"&price="+$('.item-active').attr('data-price');

                    return false;
                } else {
                    if (data.code == 600) {
                        showDialog("Banka Mesajı: " + data.message, '', '');
                        return false;
                    }
                    if (data.code == 500) {
                        showDialog(data.message, '', '');
                        return false;
                    }
                }
            },
            complete: function() {
                $('#etiketler .kredikarti .hidden').hide();
                $('#yloader1').hide();
            }
        });
    }
}
function chargeEft() {
    if ($("#eftOwner").val() == "") {
        showDialog("Lütfen havale yapan kişinin adını giriniz", '', '');
        return false;
    }



    var firstname = $("#eftOwner").val();


    var jdata = '{"firstname":"' + firstname + '", "type": "2","user_id": "' + $('#user_id').val() + '","hgs_id": "' + $('#hgs_id').val() + '", "products":["' + $("#products").val() + '"]}';
    $('#yloader2').show();
    $('#etiketler .havale .hidden').show();
    $.ajax({
        url: 'hgs/hgs/submit',
        dataType: 'json',
        data: jdata,
        type: "POST",
        success: function(data) {
            $('#etiketler .havale .hidden').hide();
            $('#yloader2').hide();
            if (data.code == 200) {
                $("#odemeonay").show();
                $('#odemeonay_logo').attr('src', 'img/tsklogo_kucuk.png');
                $('#odemeonay #havale_aciklama #reference').html(data.reference_id);
                $('#odemeonay #havale_aciklama').show();
                resetAll();
                $('html, body').animate({
                    scrollTop: $("#odemeonay").offset().top - 60
                }, 600);
                return false;
            }
        },
        complete: function() {
            $('#etiketler .havale .hidden').hide();
            $('#yloader2').hide();
        }
    });
}

function resetAll(doPaketGuncelle) {
    $("#ccOwner,#eftOwner,.ccno").val('');
    $(".remove-sticker").remove();
    $(".item").removeClass('item-active');

    $("#products,#ajax_again").val(0);
    $("#hgsyukleme").html('0 TL');
    $("#hizmetbedeli").html('0 TL');
    $("#tbedel").html('0 TL');
    $("#hidden,#hidden2").show();
    if (false !== doPaketGuncelle)
        paketGuncelle();
}

function paketGuncelle() {
    return;
    if ($("#user_id").val() > 0) {
        $.ajax({
            url: 'hgs/hgs/commission/' + $("#user_id").val(),
            dataType: 'json',
            headers: {
                'X-Epa-Request-Id': 'web.v2.' + Math.floor(Date.now() / 1000),
                'X-Epa-Service': 'epttavm',
                'X-Epa-Timestamp': TIMESTAMP,
                'X-Epa-Hash': HASH
            },
            type: "GET",
            success: function(data) {
                $.each(data.products, function(a, b) {
                    $(".item").each(function() {
                        if ($(this).attr('rel') == b.id) {
                            $(this).attr('data-commission', b.commission);
                            // console.log($(this).attr('data-commission'));
                        }
                    });


                });
            },
            error: function(jqXHR) {
                $("#paket-1,#paket-2").attr('data-package', "1.5");
                $("#paket-3,#paket-4").attr('data-package', "2");
                if (jqXHR.status === 500) {
                    showDialog('HGS sistemine bağlanılamadı. Lütfen tekrar deneyiniz', "","");
                } else {
                    showDialog('Bir hata oluştu. Lütfen tekrar deneyiniz. ', "", "");
                }
            },
            complete: function() {
            }
        });
    }
}


// Hızlı işlemler menüsünü aç
function hizliIslemPanel() {
    $('.oislem').removeClass('active');
    $('.hislem').addClass('active');
    $('#onceki-islemler').hide();
    $('#hizli-islem').show();
}


function oncekiIslemPanel() {
    $('.hislem').removeClass('active');
    $('.oislem').addClass('active');
    $('#hizli-islem').hide();
    $('#onceki-islemler').show();
}


function tcknoSave() {
    $('#tckno-loader').fadeIn(300);
    $.ajax({
        url: '/api/savetckno',
        type: "POST",
        dataType: 'json',
        data: 'tckno=' + $("#tckno_new").val() + '&user=' + $('#user_id').val(),
        success: function(obj) {
            var success = obj.success;
            var msg = obj.message;
            if (!success) {
                $('#tckno-loader').hide();
                $('#tckno_new').hide();
                $('#tckno_error').attr('value', msg);
                $('#tckno_error').show();
            } else {
                $('#btn-tcgonder').hide();
                $('#tckno-hata form')[0].reset();
                $('#tckno-hata form').hide();
                $('#tckno-hata h2').hide();
                $('h2.iziModal-header-title').show();
                $('#tckno_ok').show();
            }
        },
        complete: function () {
            $('#tckno-loader').hide();
        }
    });
}

function tcknoCancel() {
    $.ajax({
        url: '/api/tcknocancel',
        type: "POST",
        dataType: 'json',
        data: 'user=' + $('#user_id').val(),
        success: function(obj) {
            var success = obj.success;
            var msg = obj.message;
            if (success) {
                $('#user_tckno').val(1);
                $.closeOverlay();
                $('#hgs-sorgula').submit();
            }
        }
    });
}

function customerAlert() {
    var text = '<ul>' +
        "<li>epttavm.com'da bankalardan alınmış HGS ürünlerine yükleme yapılmamaktadır. <br />Yalnızca PTT ve anlaşmalı bayilerinden yapılan HGS ürünlerine yükleme yapılmaktadır.</li>" +
        "<li>epttavm.com'dan yapılan HGS yüklemelerinin düzeltme ve iptali bulunmamaktadır. <br />Yükleme yaparken yükleme yapılan ürün numarasını dikkatlice kontrol ediniz</li>" +
        '</ul>'
    showDialog(text, '', '');

}

/*
$("#frm_iletisim").find(".input-error").on("focus", function () {
   $(this).val("").removeClass("input-error");
});
*/

function contactFormSave() {
    var $inputs=["iletisim_ad", "iletisim_soyad", "iletisim_tel", "iletisim_email", "iletisim_msg"];
    var validCount = 0;
    for (var i =0; i< $inputs.length; i++) {
        var inputElem = $("#frm_iletisim").find("[name=" + $inputs[i] + "]");
        if($(inputElem).val() == "") {
            $(inputElem).addClass("input-error");
            $(inputElem).val($(inputElem).attr("data-message"));
            validCount++;
        }
        if($(inputElem).hasClass("input-error")) {
            validCount++;
        }
    }

    if(!isEmail($("#iletisim_email").val())) {
        $("#iletisim_email").addClass("input-error");
        $("#iletisim_email").val("Lütfen geçerli bir e-posta adresi giriniz");
        return false;
    }
    if(validCount > 0)
        return false;

    $('#btn-contactsend').attr('disabled', 'disabled');
    $('.loader_contact').show();
    $('#frm_iletisim form').attr('class', 'opacity');
    $.ajax({
        url: '/api/contactsend',
        type: 'POST',
        dataType: 'json',
        data: $('#frm_iletisim form').serialize(),
        success: function(obj) {
            $('#btn-contactsend').removeAttr('disabled');
            var msg = obj.message;
            var success = obj.success;
            var code = obj.code;
            $('#frm_iletisim form').removeAttr('class');
            if (!success) {
                $('#frm_iletisim_error').val(code);
                if (code == "iletisim_tel") {
                    $('#iletisim_tel').unmask();
                }
                $('#' + code).select();
                $('#' + code).addClass('input-error');
                $('#' + code).val(msg);
                $('img.' + code).fadeIn(200);
            } else {
                $('#frm_iletisim form').hide();
                $('#frm_iletisim .notices').fadeIn(200);
            }
        },
        complete:function () {
            $('.loader_contact').hide();
        }
    });
}

function trkontrol(str) {
    var latin = new Array("s","S","c","C","g","G","u","U","i","I",'O','o',"");
    var turkce = new Array("ş","Ş","ç","Ç","ğ","Ğ","ü","Ü","ı","İ",'Ö','ö'," ");
    for (var i=0; i<turkce.length; i++) {

        str = replaceAll(turkce[i], latin[i], str);
    }
    return str;
}

function replaceAll(find, replace, str) {
    return str.replace(new RegExp(find, 'g'), replace);
}

function errorHandlerFunc(jqXHR, exception) {
    var msg;
    if (jqXHR.status === 0) {
        msg = 'HGS sistemine bağlanılamadı. Lütfen tekrar deneyiniz';
    } else if (jqXHR.status == 404) {
        msg = 'Sayfa bulunamadı';
    } else if (jqXHR.status == 500) {
        msg = 'HGS sistemine bağlanılamadı. Kısa bir süre sonra tekrar deneyiniz';
    } else if (exception === 'parsererror') {
        msg = 'Veri işlenemedi. Lütfen tekrar deneyiniz.';
    } else if (exception === 'timeout') {
        msg = 'HGS sistemine bağlanılamadı. Lütfen tekrar deneyiniz';
    } else if (exception === 'abort') {
        msg = false;
    }else {
        msg = 'Bir hata oluştu. Lütfen tekrar deneyiniz. ';
    }
    return msg;
}

function loadHGS () {
    var form = $("form[name='payment-form']");
    var cardNumber = $("input[name=ccno1]").val() + $("input[name=ccno2]").val() + $("input[name=ccno3]").val() + $("input[name=ccno4]").val();
    var expiry = $("select[name=ccMonth] option:selected").val() + ' / 20' + $("select[name=ccYear] option:selected").val();
    var requestID = "hgs-web-"+new Date().getTime().toString();
    var email = $("input[name=email]");

    if (email.val() == "") {
        if (typeof $("input[name='non_user_email']").val() !== "undefined" && $("input[name='non_user_email']").val() != "")
            email.val($("input[name='non_user_email']").val());
    }

    $('<input>').attr({
        type: 'hidden',
        id: 'card_number',
        name: 'card_number',
        value: cardNumber
    }).prependTo(form);

    $('<input>').attr({
        type: 'hidden',
        id: 'card_expiry',
        name: 'card_expiry',
        value: expiry
    }).prependTo(form);

    $('<input>').attr({
        type: 'hidden',
        id: 'api[request_id]',
        name: 'api[request_id]',
        value: requestID
    }).prependTo(form);

    $("#btn-load").attr('disabled', 'disabled');

    form.submit();
}

$.ajaxSetup({
    error: function (jqXHR, exception) {
        if(errorHandlerFunc(jqXHR, exception))
            showDialog(errorHandlerFunc(jqXHR, exception), '', '');
    }
});
