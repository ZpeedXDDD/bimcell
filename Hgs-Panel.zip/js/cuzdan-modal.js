﻿





$().ready(function () {

    
   


    //$(".content").addClass("noFeedBack");    $('.refreshBtn').click(function () {
        $(this).prev('img').click()
    });


    $(".ui-dialog .ui-dialog-content").css("border-radius", "6px");

    if (!navigator.userAgent.match(/Android/i)) {
        $('#txtTelC').mask("0 ?(999) 9999999", {
            completed: function () {
                var numbers = this.val().replace(/()-/g, '');
            }
        });


        
    }




    $('#txtTelC').keypress(function (e) {

        if ($('#txtTelC').val().length > -1 || $("#txtTelC").val()) {

            $(".bireysel-valid .errorContainer").fadeOut();
        }
    });


    

    $('#CaptchaMobilCuzdan').keypress(function (e) {

        if ($('#CaptchaMobilCuzdan').val().length > -1 || $("#CaptchaMobilCuzdan").val()) {

            $(".bireysel-valid-captcha .errorContainer").fadeOut();
        }
    });



    $.Page.SendForm.Callback = function (response) {
        $(".app-banner-container-right-content p.info").show();
        $(".app-banner-container-right img.valid-modal").hide();

        $(".app-banner-container-right-content p.info").show();
        $(".app-banner-container-right img.valid-modal").hide();

        $(".timer-modal-backward").hide();
        $(".timer-modal-backward").show();
        if (response.StatusCode == 200) {
            $(".app-banner-container-right img.valid-modal").show();

            setTimeout(function () {
                $(".timer-modal-div").show();
            }, 3000);


            $('.valid-modal').click(function () {
                var imgclick = $(".valid-modal");
                button.attr("disabled", "disabled");
                setTimeout(function () {
                    button.removeAttr('disabled');
                }, 8000);

            });


            $('.timer-modal-backward').backward_timer({
                seconds: 08,
                format: 's%',
                on_exhausted: function (timer) {
                    $(".timer-modal-div").hide();
                    $(".valid-modal").hide();
                }
            });

            $('.timer-modal-backward').backward_timer('start')

            $(".cuzdan-modal .inputContainer input").each(function () {
                $(this).val("");
            });
            if (!navigator.userAgent.match(/Android/i)) {
                $('#txtTelC').mask("0 ?(999) 9999999", {
                    completed: function () {
                        var numbers = this.val().replace(/()-/g, '');
                    }
                });


               

            }
            $("img.valid-modal").on("click", function () {
                $("img.valid-modal").hide();
            });
        } else if (response.StatusCode == 603) {
            $(".bireysel-valid-captcha .errorContainer.wrong span").html(response.Message);
            $(".bireysel-valid-captcha .errorContainer.wrong").fadeIn();            
        } else if (response.StatusCode == 403) {
            $(".app-banner-container-right img.limit-modal").show();
            $(".cuzdan-modal .inputContainer input").each(function () {
                $(this).val("");
            });



            if (!navigator.userAgent.match(/Android/i)) {
                $('#txtTelC').mask("0 ?(999) 9999999", {
                    completed: function () {
                        var numbers = this.val().replace(/()-/g, '');
                    }
                });



                
            }
            $("img.limit-modal").on("click", function () {
                $("img.limit-modal").hide();
            });
        } else if (response.StatusCode == 405) {
            $(".app-banner-container-right img.ip-limit").show();
            $(".cuzdan-modal .inputContainer input").each(function () {
                $(this).val("");
            });



            if (!navigator.userAgent.match(/Android/i)) {
                $('#txtTelC').mask("0 ?(999) 9999999", {
                    completed: function () {
                        var numbers = this.val().replace(/()-/g, '');
                    }
                });



                
            }
            $("img.ip-limit").on("click", function () {
                $("img.ip-limit").hide();
            });
        } else if (response.StatusCode == 601) {
            $(".bireysel-valid:visible .errorContainer.wrong").fadeIn();           
        }
        else {
            alert(response.Message);
        }

        $('#ctl00_ucCuzdanModal_CaptchaMobilCuzdanForm').trigger('click');

    }



    $("#Cuzdan-Modal").dialog({
        autoOpen: false,
        modal: true,
        dialogClass: "cuzdan-modal",
        open: function (event, ui) {

            $(".cuzdan-modal .inputContainer input").each(function () {
                $(this).val("");
            });
            $(".cuzdan-modal .errorContainer").each(function () {
                $(this).hide();
            });
            if (!navigator.userAgent.match(/Android/i)) {
                $('#txtTelC').mask("0 ?(999) 9999999", {
                    completed: function () {
                        var numbers = this.val().replace(/()-/g, '');
                    }
                });

               
            }



        },
        width: 909,
        height: 620
    });

    $(".ui-dialog.cuzdan-modal .ui-dialog-titlebar-close").click(function () {
        $("#txtTelC").val("");
    })


    var arrow_keys_handler = function (e) {
        switch (e.keyCode) {
            case 37: case 39: case 38: case 33: case 34: case 40: // Arrow keys
            
            default: break; // do not block other keys
        }
    };
    window.addEventListener("keydown", arrow_keys_handler, false);


    $("#txtTelC").change(function () {
        if ($(this).val().length == 2) {
            $(this).val("");
        }
    });

   

    $(".cuzdan-sube-button").click(function () {

        $("img.modal-data-img").each(function () {
            var sou = $(this).attr("data-src");
            $(this).attr("src", sou);
        });


       


        $('.app-banner-flixeder').flexslider({
            animation: "fade",
            directionNav: false,
            start: function () {
                $("#Cuzdan-Modal").dialog("open");
            }
        });

        

        
        $('#ctl00_ucCuzdanModal_CaptchaMobilCuzdanForm').trigger('click');
       
        

        return false;

    });

   
    
    

    $(".errorContainer").hide();
    $("#buton-submit-cuzdan").click(function () {
        $(".bireysel-valid:visible .errorContainer.wrong").hide();
        var degerSayi = $("#txtTelC").val().replace(/_/g, " ").length;
        var valid = true;
        var lenTel;
        if (!navigator.userAgent.match(/Android/i)) {
            lenTel = 15;
            if ($("#txtTelC").val().slice(3, 4) != "5" && degerSayi == lenTel) {
                $(".bireysel-valid .errorContainer").fadeOut();
                $(".bireysel-valid .errorContainer.wrong").fadeIn();
                valid = false;
            } else {
                $(".bireysel-valid .errorContainer.wrong").fadeOut();
            }
        } else {
            lenTel = 11;
        }
        if (degerSayi <= 0 || degerSayi < lenTel) {
            $(".bireysel-valid .errorContainer.sttc").fadeIn();
            valid = false;
        } else {
            $(".bireysel-valid .errorContainer.sttc").fadeOut();
        }
        degerSayi = $("#CaptchaMobilCuzdan").val().length;
        if (degerSayi <= 0) {
            $(".bireysel-valid-captcha .errorContainer.wrong").hide();
            $(".bireysel-valid-captcha .errorContainer.blank").fadeIn();
            valid = false;
        } else {
            $(".bireysel-valid-captcha .errorContainer.blank").fadeOut();
        }
        if (valid) {
            $.Page.SendForm($("#txtTelC").val(), $("#CaptchaMobilCuzdan").val(), null);
        }

        $(".error.rounder").each(function () {
            $(this).addClass("fl");
        });
    });

});

$(window).load(function () {
    if (window.location.hash == "#yk-cuzdan-indir") {
        $('.app-banner-flixeder').flexslider({
            animation: "fade",
            directionNav: false,
            start: function () {
                $("#Cuzdan-Modal").dialog("open");
            }
        });
        
        $("img.modal-data-img").each(function () {
            var sou = $(this).attr("data-src");
            $(this).attr("src", sou);
        });
    }

    if (window.location.hash == "#yk-cuzdan-indir?worldcard") {
        $('.app-banner-flixeder').flexslider({
            animation: "fade",
            directionNav: false,
            start: function () {
                $("#Cuzdan-Modal").dialog("open");
            }
        });

        $("img.modal-data-img").each(function () {
            var sou = $(this).attr("data-src");
            $(this).attr("src", sou);
        });
    }

});




